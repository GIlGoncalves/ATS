// $ANTLR 3.2 Sep 23, 2009 12:02:23 parser/Grammerats.g 2016-10-26 18:01:57

  package parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class GrammeratsParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "AtribF", "InitF", "Div", "Times", "Minus", "Plus", "Less", "Bigger", "Diff", "Equal", "And", "Or", "Program", "StmList", "VarList", "Assignment", "ListProgram", "Id", "IdVar", "Int", "OpExp", "StatementReturn", "StatementIteration", "StatementSelection", "StatementAssignment", "StatementDeclaration", "ForStatement", "WhileStatement", "Declaration", "TypeDouble", "TypeFloat", "TypeChar", "TypeInt", "TypeVoid", "AssignmentDeclaration", "SimpleDeclaration", "ReturnStatement", "DeclarationAssignment", "IfStatement", "IfElse", "ID", "INT", "WS", "'Program'", "'program'", "'{'", "'}'", "';'", "','", "'='", "'||'", "'('", "')'", "'/'", "'*'", "'-'", "'+'", "'<'", "'>'", "'!='", "'=='", "'&&'", "'if'", "'then'", "'else'", "'while'", "'for'", "'return'", "'void'", "'int'", "'char'", "'float'", "'double'"
    };
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__66=66;
    public static final int T__67=67;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__62=62;
    public static final int Bigger=17;
    public static final int T__63=63;
    public static final int WhileStatement=37;
    public static final int Diff=18;
    public static final int TypeDouble=39;
    public static final int TypeInt=42;
    public static final int ID=50;
    public static final int T__61=61;
    public static final int T__60=60;
    public static final int EOF=-1;
    public static final int ForStatement=36;
    public static final int Program=22;
    public static final int Int=29;
    public static final int StmList=23;
    public static final int T__55=55;
    public static final int StatementIteration=32;
    public static final int T__56=56;
    public static final int InitF=11;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__53=53;
    public static final int AtribF=10;
    public static final int T__54=54;
    public static final int Declaration=38;
    public static final int Less=16;
    public static final int T__59=59;
    public static final int IfElse=49;
    public static final int TypeChar=41;
    public static final int ListProgram=26;
    public static final int ReturnStatement=46;
    public static final int Or=21;
    public static final int IdVar=28;
    public static final int Id=27;
    public static final int And=20;
    public static final int Div=12;
    public static final int SimpleDeclaration=45;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int StatementDeclaration=35;
    public static final int T__82=82;
    public static final int Assignment=25;
    public static final int StatementAssignment=34;
    public static final int StatementReturn=31;
    public static final int INT=51;
    public static final int Equal=19;
    public static final int OpExp=30;
    public static final int Plus=15;
    public static final int Minus=14;
    public static final int WS=52;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int T__70=70;
    public static final int Times=13;
    public static final int AssignmentDeclaration=44;
    public static final int TypeVoid=43;
    public static final int VarList=24;
    public static final int IfStatement=48;
    public static final int T__76=76;
    public static final int T__75=75;
    public static final int TypeFloat=40;
    public static final int T__74=74;
    public static final int T__73=73;
    public static final int T__79=79;
    public static final int DeclarationAssignment=47;
    public static final int T__78=78;
    public static final int T__77=77;
    public static final int StatementSelection=33;

    // delegates
    // delegators


        public GrammeratsParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public GrammeratsParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return GrammeratsParser.tokenNames; }
    public String getGrammarFileName() { return "parser/Grammerats.g"; }


    public static class programs_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "programs"
    // parser/Grammerats.g:15:1: programs : ( program )+ EOF -> ^( ListProgram ( program )+ ) ;
    public final GrammeratsParser.programs_return programs() throws RecognitionException {
        GrammeratsParser.programs_return retval = new GrammeratsParser.programs_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token EOF2=null;
        GrammeratsParser.program_return program1 = null;


        Tree EOF2_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_program=new RewriteRuleSubtreeStream(adaptor,"rule program");
        try {
            // parser/Grammerats.g:16:5: ( ( program )+ EOF -> ^( ListProgram ( program )+ ) )
            // parser/Grammerats.g:16:7: ( program )+ EOF
            {
            // parser/Grammerats.g:16:7: ( program )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=53 && LA1_0<=54)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // parser/Grammerats.g:16:7: program
            	    {
            	    pushFollow(FOLLOW_program_in_programs58);
            	    program1=program();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_program.add(program1.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            EOF2=(Token)match(input,EOF,FOLLOW_EOF_in_programs61); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF2);



            // AST REWRITE
            // elements: program
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 16:21: -> ^( ListProgram ( program )+ )
            {
                // parser/Grammerats.g:16:25: ^( ListProgram ( program )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ListProgram, "ListProgram"), root_1);

                if ( !(stream_program.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_program.hasNext() ) {
                    adaptor.addChild(root_1, stream_program.nextTree());

                }
                stream_program.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "programs"

    public static class program_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "program"
    // parser/Grammerats.g:19:1: program : ( 'Program' | 'program' ) idVar statements -> ^( Program idVar statements ) ;
    public final GrammeratsParser.program_return program() throws RecognitionException {
        GrammeratsParser.program_return retval = new GrammeratsParser.program_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal3=null;
        Token string_literal4=null;
        GrammeratsParser.idVar_return idVar5 = null;

        GrammeratsParser.statements_return statements6 = null;


        Tree string_literal3_tree=null;
        Tree string_literal4_tree=null;
        RewriteRuleTokenStream stream_53=new RewriteRuleTokenStream(adaptor,"token 53");
        RewriteRuleTokenStream stream_54=new RewriteRuleTokenStream(adaptor,"token 54");
        RewriteRuleSubtreeStream stream_statements=new RewriteRuleSubtreeStream(adaptor,"rule statements");
        RewriteRuleSubtreeStream stream_idVar=new RewriteRuleSubtreeStream(adaptor,"rule idVar");
        try {
            // parser/Grammerats.g:20:5: ( ( 'Program' | 'program' ) idVar statements -> ^( Program idVar statements ) )
            // parser/Grammerats.g:20:9: ( 'Program' | 'program' ) idVar statements
            {
            // parser/Grammerats.g:20:9: ( 'Program' | 'program' )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==53) ) {
                alt2=1;
            }
            else if ( (LA2_0==54) ) {
                alt2=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // parser/Grammerats.g:20:10: 'Program'
                    {
                    string_literal3=(Token)match(input,53,FOLLOW_53_in_program92); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_53.add(string_literal3);


                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:20:22: 'program'
                    {
                    string_literal4=(Token)match(input,54,FOLLOW_54_in_program96); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_54.add(string_literal4);


                    }
                    break;

            }

            pushFollow(FOLLOW_idVar_in_program99);
            idVar5=idVar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_idVar.add(idVar5.getTree());
            pushFollow(FOLLOW_statements_in_program101);
            statements6=statements();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_statements.add(statements6.getTree());


            // AST REWRITE
            // elements: statements, idVar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 20:52: -> ^( Program idVar statements )
            {
                // parser/Grammerats.g:20:56: ^( Program idVar statements )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Program, "Program"), root_1);

                adaptor.addChild(root_1, stream_idVar.nextTree());
                adaptor.addChild(root_1, stream_statements.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "program"

    public static class statements_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statements"
    // parser/Grammerats.g:24:1: statements : ( ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) ) | (e1= statement -> ^( StmList $e1) ) ) ;
    public final GrammeratsParser.statements_return statements() throws RecognitionException {
        GrammeratsParser.statements_return retval = new GrammeratsParser.statements_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal7=null;
        Token char_literal9=null;
        GrammeratsParser.statement_return e1 = null;

        GrammeratsParser.statement_return statement8 = null;


        Tree char_literal7_tree=null;
        Tree char_literal9_tree=null;
        RewriteRuleTokenStream stream_56=new RewriteRuleTokenStream(adaptor,"token 56");
        RewriteRuleTokenStream stream_55=new RewriteRuleTokenStream(adaptor,"token 55");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        try {
            // parser/Grammerats.g:25:5: ( ( ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) ) | (e1= statement -> ^( StmList $e1) ) ) )
            // parser/Grammerats.g:25:9: ( ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) ) | (e1= statement -> ^( StmList $e1) ) )
            {
            // parser/Grammerats.g:25:9: ( ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) ) | (e1= statement -> ^( StmList $e1) ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==55) ) {
                alt4=1;
            }
            else if ( (LA4_0==ID||LA4_0==72||(LA4_0>=75 && LA4_0<=82)) ) {
                alt4=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // parser/Grammerats.g:25:10: ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) )
                    {
                    // parser/Grammerats.g:25:10: ( '{' ( statement )+ '}' -> ^( StmList ( statement )+ ) )
                    // parser/Grammerats.g:25:11: '{' ( statement )+ '}'
                    {
                    char_literal7=(Token)match(input,55,FOLLOW_55_in_statements145); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_55.add(char_literal7);

                    // parser/Grammerats.g:25:15: ( statement )+
                    int cnt3=0;
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==ID||LA3_0==72||(LA3_0>=75 && LA3_0<=82)) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // parser/Grammerats.g:25:15: statement
                    	    {
                    	    pushFollow(FOLLOW_statement_in_statements147);
                    	    statement8=statement();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_statement.add(statement8.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt3 >= 1 ) break loop3;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(3, input);
                                throw eee;
                        }
                        cnt3++;
                    } while (true);

                    char_literal9=(Token)match(input,56,FOLLOW_56_in_statements150); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_56.add(char_literal9);



                    // AST REWRITE
                    // elements: statement
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 25:31: -> ^( StmList ( statement )+ )
                    {
                        // parser/Grammerats.g:25:35: ^( StmList ( statement )+ )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StmList, "StmList"), root_1);

                        if ( !(stream_statement.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_statement.hasNext() ) {
                            adaptor.addChild(root_1, stream_statement.nextTree());

                        }
                        stream_statement.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:26:11: (e1= statement -> ^( StmList $e1) )
                    {
                    // parser/Grammerats.g:26:11: (e1= statement -> ^( StmList $e1) )
                    // parser/Grammerats.g:26:12: e1= statement
                    {
                    pushFollow(FOLLOW_statement_in_statements177);
                    e1=statement();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statement.add(e1.getTree());


                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 26:25: -> ^( StmList $e1)
                    {
                        // parser/Grammerats.g:26:28: ^( StmList $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StmList, "StmList"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statements"

    public static class statement_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // parser/Grammerats.g:30:1: statement : ( declaration ';' -> ^( StatementDeclaration declaration ) | assignment ';' -> ^( StatementAssignment assignment ) | selection -> ^( StatementSelection selection ) | iteration -> ^( StatementIteration iteration ) | stReturn ';' -> ^( StatementReturn stReturn ) );
    public final GrammeratsParser.statement_return statement() throws RecognitionException {
        GrammeratsParser.statement_return retval = new GrammeratsParser.statement_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal11=null;
        Token char_literal13=null;
        Token char_literal17=null;
        GrammeratsParser.declaration_return declaration10 = null;

        GrammeratsParser.assignment_return assignment12 = null;

        GrammeratsParser.selection_return selection14 = null;

        GrammeratsParser.iteration_return iteration15 = null;

        GrammeratsParser.stReturn_return stReturn16 = null;


        Tree char_literal11_tree=null;
        Tree char_literal13_tree=null;
        Tree char_literal17_tree=null;
        RewriteRuleTokenStream stream_57=new RewriteRuleTokenStream(adaptor,"token 57");
        RewriteRuleSubtreeStream stream_stReturn=new RewriteRuleSubtreeStream(adaptor,"rule stReturn");
        RewriteRuleSubtreeStream stream_assignment=new RewriteRuleSubtreeStream(adaptor,"rule assignment");
        RewriteRuleSubtreeStream stream_declaration=new RewriteRuleSubtreeStream(adaptor,"rule declaration");
        RewriteRuleSubtreeStream stream_selection=new RewriteRuleSubtreeStream(adaptor,"rule selection");
        RewriteRuleSubtreeStream stream_iteration=new RewriteRuleSubtreeStream(adaptor,"rule iteration");
        try {
            // parser/Grammerats.g:31:5: ( declaration ';' -> ^( StatementDeclaration declaration ) | assignment ';' -> ^( StatementAssignment assignment ) | selection -> ^( StatementSelection selection ) | iteration -> ^( StatementIteration iteration ) | stReturn ';' -> ^( StatementReturn stReturn ) )
            int alt5=5;
            switch ( input.LA(1) ) {
            case 78:
            case 79:
            case 80:
            case 81:
            case 82:
                {
                alt5=1;
                }
                break;
            case ID:
                {
                alt5=2;
                }
                break;
            case 72:
                {
                alt5=3;
                }
                break;
            case 75:
            case 76:
                {
                alt5=4;
                }
                break;
            case 77:
                {
                alt5=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // parser/Grammerats.g:31:7: declaration ';'
                    {
                    pushFollow(FOLLOW_declaration_in_statement218);
                    declaration10=declaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_declaration.add(declaration10.getTree());
                    char_literal11=(Token)match(input,57,FOLLOW_57_in_statement220); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_57.add(char_literal11);



                    // AST REWRITE
                    // elements: declaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 31:25: -> ^( StatementDeclaration declaration )
                    {
                        // parser/Grammerats.g:31:29: ^( StatementDeclaration declaration )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StatementDeclaration, "StatementDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_declaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:32:7: assignment ';'
                    {
                    pushFollow(FOLLOW_assignment_in_statement239);
                    assignment12=assignment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment.add(assignment12.getTree());
                    char_literal13=(Token)match(input,57,FOLLOW_57_in_statement241); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_57.add(char_literal13);



                    // AST REWRITE
                    // elements: assignment
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 32:25: -> ^( StatementAssignment assignment )
                    {
                        // parser/Grammerats.g:32:29: ^( StatementAssignment assignment )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StatementAssignment, "StatementAssignment"), root_1);

                        adaptor.addChild(root_1, stream_assignment.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // parser/Grammerats.g:33:7: selection
                    {
                    pushFollow(FOLLOW_selection_in_statement261);
                    selection14=selection();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_selection.add(selection14.getTree());


                    // AST REWRITE
                    // elements: selection
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 33:25: -> ^( StatementSelection selection )
                    {
                        // parser/Grammerats.g:33:29: ^( StatementSelection selection )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StatementSelection, "StatementSelection"), root_1);

                        adaptor.addChild(root_1, stream_selection.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // parser/Grammerats.g:34:7: iteration
                    {
                    pushFollow(FOLLOW_iteration_in_statement286);
                    iteration15=iteration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_iteration.add(iteration15.getTree());


                    // AST REWRITE
                    // elements: iteration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 34:25: -> ^( StatementIteration iteration )
                    {
                        // parser/Grammerats.g:34:29: ^( StatementIteration iteration )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StatementIteration, "StatementIteration"), root_1);

                        adaptor.addChild(root_1, stream_iteration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // parser/Grammerats.g:35:7: stReturn ';'
                    {
                    pushFollow(FOLLOW_stReturn_in_statement311);
                    stReturn16=stReturn();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_stReturn.add(stReturn16.getTree());
                    char_literal17=(Token)match(input,57,FOLLOW_57_in_statement313); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_57.add(char_literal17);



                    // AST REWRITE
                    // elements: stReturn
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 35:27: -> ^( StatementReturn stReturn )
                    {
                        // parser/Grammerats.g:35:31: ^( StatementReturn stReturn )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(StatementReturn, "StatementReturn"), root_1);

                        adaptor.addChild(root_1, stream_stReturn.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class declaration_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "declaration"
    // parser/Grammerats.g:38:1: declaration : ( simpleDeclaration -> ^( SimpleDeclaration simpleDeclaration ) | assignmentDeclaration -> ^( AssignmentDeclaration assignmentDeclaration ) );
    public final GrammeratsParser.declaration_return declaration() throws RecognitionException {
        GrammeratsParser.declaration_return retval = new GrammeratsParser.declaration_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        GrammeratsParser.simpleDeclaration_return simpleDeclaration18 = null;

        GrammeratsParser.assignmentDeclaration_return assignmentDeclaration19 = null;


        RewriteRuleSubtreeStream stream_assignmentDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule assignmentDeclaration");
        RewriteRuleSubtreeStream stream_simpleDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule simpleDeclaration");
        try {
            // parser/Grammerats.g:39:5: ( simpleDeclaration -> ^( SimpleDeclaration simpleDeclaration ) | assignmentDeclaration -> ^( AssignmentDeclaration assignmentDeclaration ) )
            int alt6=2;
            switch ( input.LA(1) ) {
            case 78:
                {
                int LA6_1 = input.LA(2);

                if ( (LA6_1==ID) ) {
                    int LA6_6 = input.LA(3);

                    if ( ((LA6_6>=57 && LA6_6<=58)) ) {
                        alt6=1;
                    }
                    else if ( (LA6_6==59) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 1, input);

                    throw nvae;
                }
                }
                break;
            case 79:
                {
                int LA6_2 = input.LA(2);

                if ( (LA6_2==ID) ) {
                    int LA6_6 = input.LA(3);

                    if ( ((LA6_6>=57 && LA6_6<=58)) ) {
                        alt6=1;
                    }
                    else if ( (LA6_6==59) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }
                }
                break;
            case 80:
                {
                int LA6_3 = input.LA(2);

                if ( (LA6_3==ID) ) {
                    int LA6_6 = input.LA(3);

                    if ( ((LA6_6>=57 && LA6_6<=58)) ) {
                        alt6=1;
                    }
                    else if ( (LA6_6==59) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 3, input);

                    throw nvae;
                }
                }
                break;
            case 81:
                {
                int LA6_4 = input.LA(2);

                if ( (LA6_4==ID) ) {
                    int LA6_6 = input.LA(3);

                    if ( ((LA6_6>=57 && LA6_6<=58)) ) {
                        alt6=1;
                    }
                    else if ( (LA6_6==59) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 4, input);

                    throw nvae;
                }
                }
                break;
            case 82:
                {
                int LA6_5 = input.LA(2);

                if ( (LA6_5==ID) ) {
                    int LA6_6 = input.LA(3);

                    if ( ((LA6_6>=57 && LA6_6<=58)) ) {
                        alt6=1;
                    }
                    else if ( (LA6_6==59) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 6, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 5, input);

                    throw nvae;
                }
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // parser/Grammerats.g:39:7: simpleDeclaration
                    {
                    pushFollow(FOLLOW_simpleDeclaration_in_declaration347);
                    simpleDeclaration18=simpleDeclaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_simpleDeclaration.add(simpleDeclaration18.getTree());


                    // AST REWRITE
                    // elements: simpleDeclaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 39:29: -> ^( SimpleDeclaration simpleDeclaration )
                    {
                        // parser/Grammerats.g:39:33: ^( SimpleDeclaration simpleDeclaration )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(SimpleDeclaration, "SimpleDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_simpleDeclaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:40:7: assignmentDeclaration
                    {
                    pushFollow(FOLLOW_assignmentDeclaration_in_declaration368);
                    assignmentDeclaration19=assignmentDeclaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignmentDeclaration.add(assignmentDeclaration19.getTree());


                    // AST REWRITE
                    // elements: assignmentDeclaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 40:29: -> ^( AssignmentDeclaration assignmentDeclaration )
                    {
                        // parser/Grammerats.g:40:33: ^( AssignmentDeclaration assignmentDeclaration )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(AssignmentDeclaration, "AssignmentDeclaration"), root_1);

                        adaptor.addChild(root_1, stream_assignmentDeclaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "declaration"

    public static class simpleDeclaration_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleDeclaration"
    // parser/Grammerats.g:43:1: simpleDeclaration : type varlist -> ^( Declaration type varlist ) ;
    public final GrammeratsParser.simpleDeclaration_return simpleDeclaration() throws RecognitionException {
        GrammeratsParser.simpleDeclaration_return retval = new GrammeratsParser.simpleDeclaration_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        GrammeratsParser.type_return type20 = null;

        GrammeratsParser.varlist_return varlist21 = null;


        RewriteRuleSubtreeStream stream_varlist=new RewriteRuleSubtreeStream(adaptor,"rule varlist");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // parser/Grammerats.g:44:5: ( type varlist -> ^( Declaration type varlist ) )
            // parser/Grammerats.g:44:7: type varlist
            {
            pushFollow(FOLLOW_type_in_simpleDeclaration399);
            type20=type();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_type.add(type20.getTree());
            pushFollow(FOLLOW_varlist_in_simpleDeclaration401);
            varlist21=varlist();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_varlist.add(varlist21.getTree());


            // AST REWRITE
            // elements: varlist, type
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 44:20: -> ^( Declaration type varlist )
            {
                // parser/Grammerats.g:44:24: ^( Declaration type varlist )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Declaration, "Declaration"), root_1);

                adaptor.addChild(root_1, stream_type.nextTree());
                adaptor.addChild(root_1, stream_varlist.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleDeclaration"

    public static class varlist_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "varlist"
    // parser/Grammerats.g:47:1: varlist : idVar ( ',' idVar )* -> ^( VarList ( idVar )+ ) ;
    public final GrammeratsParser.varlist_return varlist() throws RecognitionException {
        GrammeratsParser.varlist_return retval = new GrammeratsParser.varlist_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal23=null;
        GrammeratsParser.idVar_return idVar22 = null;

        GrammeratsParser.idVar_return idVar24 = null;


        Tree char_literal23_tree=null;
        RewriteRuleTokenStream stream_58=new RewriteRuleTokenStream(adaptor,"token 58");
        RewriteRuleSubtreeStream stream_idVar=new RewriteRuleSubtreeStream(adaptor,"rule idVar");
        try {
            // parser/Grammerats.g:48:5: ( idVar ( ',' idVar )* -> ^( VarList ( idVar )+ ) )
            // parser/Grammerats.g:48:7: idVar ( ',' idVar )*
            {
            pushFollow(FOLLOW_idVar_in_varlist429);
            idVar22=idVar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_idVar.add(idVar22.getTree());
            // parser/Grammerats.g:48:13: ( ',' idVar )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==58) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // parser/Grammerats.g:48:14: ',' idVar
            	    {
            	    char_literal23=(Token)match(input,58,FOLLOW_58_in_varlist432); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_58.add(char_literal23);

            	    pushFollow(FOLLOW_idVar_in_varlist434);
            	    idVar24=idVar();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_idVar.add(idVar24.getTree());

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);



            // AST REWRITE
            // elements: idVar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 48:26: -> ^( VarList ( idVar )+ )
            {
                // parser/Grammerats.g:48:29: ^( VarList ( idVar )+ )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(VarList, "VarList"), root_1);

                if ( !(stream_idVar.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_idVar.hasNext() ) {
                    adaptor.addChild(root_1, stream_idVar.nextTree());

                }
                stream_idVar.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "varlist"

    public static class assignmentDeclaration_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignmentDeclaration"
    // parser/Grammerats.g:51:1: assignmentDeclaration : type assignment -> ^( DeclarationAssignment type assignment ) ;
    public final GrammeratsParser.assignmentDeclaration_return assignmentDeclaration() throws RecognitionException {
        GrammeratsParser.assignmentDeclaration_return retval = new GrammeratsParser.assignmentDeclaration_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        GrammeratsParser.type_return type25 = null;

        GrammeratsParser.assignment_return assignment26 = null;


        RewriteRuleSubtreeStream stream_assignment=new RewriteRuleSubtreeStream(adaptor,"rule assignment");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // parser/Grammerats.g:52:5: ( type assignment -> ^( DeclarationAssignment type assignment ) )
            // parser/Grammerats.g:52:7: type assignment
            {
            pushFollow(FOLLOW_type_in_assignmentDeclaration467);
            type25=type();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_type.add(type25.getTree());
            pushFollow(FOLLOW_assignment_in_assignmentDeclaration469);
            assignment26=assignment();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_assignment.add(assignment26.getTree());


            // AST REWRITE
            // elements: type, assignment
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 52:25: -> ^( DeclarationAssignment type assignment )
            {
                // parser/Grammerats.g:52:29: ^( DeclarationAssignment type assignment )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(DeclarationAssignment, "DeclarationAssignment"), root_1);

                adaptor.addChild(root_1, stream_type.nextTree());
                adaptor.addChild(root_1, stream_assignment.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignmentDeclaration"

    public static class assignment_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment"
    // parser/Grammerats.g:55:1: assignment : idVar '=' expression -> ^( Assignment idVar expression ) ;
    public final GrammeratsParser.assignment_return assignment() throws RecognitionException {
        GrammeratsParser.assignment_return retval = new GrammeratsParser.assignment_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal28=null;
        GrammeratsParser.idVar_return idVar27 = null;

        GrammeratsParser.expression_return expression29 = null;


        Tree char_literal28_tree=null;
        RewriteRuleTokenStream stream_59=new RewriteRuleTokenStream(adaptor,"token 59");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_idVar=new RewriteRuleSubtreeStream(adaptor,"rule idVar");
        try {
            // parser/Grammerats.g:56:5: ( idVar '=' expression -> ^( Assignment idVar expression ) )
            // parser/Grammerats.g:56:7: idVar '=' expression
            {
            pushFollow(FOLLOW_idVar_in_assignment503);
            idVar27=idVar();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_idVar.add(idVar27.getTree());
            char_literal28=(Token)match(input,59,FOLLOW_59_in_assignment505); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_59.add(char_literal28);

            pushFollow(FOLLOW_expression_in_assignment507);
            expression29=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression29.getTree());


            // AST REWRITE
            // elements: expression, idVar
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 56:32: -> ^( Assignment idVar expression )
            {
                // parser/Grammerats.g:56:36: ^( Assignment idVar expression )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Assignment, "Assignment"), root_1);

                adaptor.addChild(root_1, stream_idVar.nextTree());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment"

    public static class expression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // parser/Grammerats.g:59:1: expression : (e1= logicalAndExpression ) ( ( '||' e2= logicalAndExpression )+ -> ^( OpExp $e1 ^( Or ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.expression_return expression() throws RecognitionException {
        GrammeratsParser.expression_return retval = new GrammeratsParser.expression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal30=null;
        GrammeratsParser.logicalAndExpression_return e1 = null;

        GrammeratsParser.logicalAndExpression_return e2 = null;


        Tree string_literal30_tree=null;
        RewriteRuleTokenStream stream_60=new RewriteRuleTokenStream(adaptor,"token 60");
        RewriteRuleSubtreeStream stream_logicalAndExpression=new RewriteRuleSubtreeStream(adaptor,"rule logicalAndExpression");
        try {
            // parser/Grammerats.g:60:5: ( (e1= logicalAndExpression ) ( ( '||' e2= logicalAndExpression )+ -> ^( OpExp $e1 ^( Or ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:60:9: (e1= logicalAndExpression ) ( ( '||' e2= logicalAndExpression )+ -> ^( OpExp $e1 ^( Or ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:60:9: (e1= logicalAndExpression )
            // parser/Grammerats.g:60:10: e1= logicalAndExpression
            {
            pushFollow(FOLLOW_logicalAndExpression_in_expression550);
            e1=logicalAndExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_logicalAndExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:60:37: ( ( '||' e2= logicalAndExpression )+ -> ^( OpExp $e1 ^( Or ) $e2) | -> ^( $e1) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==60) ) {
                alt9=1;
            }
            else if ( (LA9_0==57||LA9_0==62) ) {
                alt9=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // parser/Grammerats.g:60:38: ( '||' e2= logicalAndExpression )+
                    {
                    // parser/Grammerats.g:60:38: ( '||' e2= logicalAndExpression )+
                    int cnt8=0;
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==60) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // parser/Grammerats.g:60:39: '||' e2= logicalAndExpression
                    	    {
                    	    string_literal30=(Token)match(input,60,FOLLOW_60_in_expression555); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_60.add(string_literal30);

                    	    pushFollow(FOLLOW_logicalAndExpression_in_expression561);
                    	    e2=logicalAndExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_logicalAndExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt8 >= 1 ) break loop8;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(8, input);
                                throw eee;
                        }
                        cnt8++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 60:74: -> ^( OpExp $e1 ^( Or ) $e2)
                    {
                        // parser/Grammerats.g:60:78: ^( OpExp $e1 ^( Or ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:60:90: ^( Or )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Or, "Or"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:60:103: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 60:103: -> ^( $e1)
                    {
                        // parser/Grammerats.g:60:106: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class primaryExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "primaryExpression"
    // parser/Grammerats.g:63:1: primaryExpression : ( ID -> ^( IdVar ID ) | INT -> ^( Int INT ) | '(' expression ')' -> ^( expression ) );
    public final GrammeratsParser.primaryExpression_return primaryExpression() throws RecognitionException {
        GrammeratsParser.primaryExpression_return retval = new GrammeratsParser.primaryExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token ID31=null;
        Token INT32=null;
        Token char_literal33=null;
        Token char_literal35=null;
        GrammeratsParser.expression_return expression34 = null;


        Tree ID31_tree=null;
        Tree INT32_tree=null;
        Tree char_literal33_tree=null;
        Tree char_literal35_tree=null;
        RewriteRuleTokenStream stream_INT=new RewriteRuleTokenStream(adaptor,"token INT");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // parser/Grammerats.g:64:9: ( ID -> ^( IdVar ID ) | INT -> ^( Int INT ) | '(' expression ')' -> ^( expression ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case ID:
                {
                alt10=1;
                }
                break;
            case INT:
                {
                alt10=2;
                }
                break;
            case 61:
                {
                alt10=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // parser/Grammerats.g:64:13: ID
                    {
                    ID31=(Token)match(input,ID,FOLLOW_ID_in_primaryExpression615); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ID.add(ID31);



                    // AST REWRITE
                    // elements: ID
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 64:17: -> ^( IdVar ID )
                    {
                        // parser/Grammerats.g:64:20: ^( IdVar ID )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(IdVar, "IdVar"), root_1);

                        adaptor.addChild(root_1, stream_ID.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:65:13: INT
                    {
                    INT32=(Token)match(input,INT,FOLLOW_INT_in_primaryExpression638); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INT.add(INT32);



                    // AST REWRITE
                    // elements: INT
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 65:21: -> ^( Int INT )
                    {
                        // parser/Grammerats.g:65:24: ^( Int INT )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Int, "Int"), root_1);

                        adaptor.addChild(root_1, stream_INT.nextNode());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // parser/Grammerats.g:66:13: '(' expression ')'
                    {
                    char_literal33=(Token)match(input,61,FOLLOW_61_in_primaryExpression669); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_61.add(char_literal33);

                    pushFollow(FOLLOW_expression_in_primaryExpression671);
                    expression34=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression34.getTree());
                    char_literal35=(Token)match(input,62,FOLLOW_62_in_primaryExpression673); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_62.add(char_literal35);



                    // AST REWRITE
                    // elements: expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 66:32: -> ^( expression )
                    {
                        // parser/Grammerats.g:66:35: ^( expression )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_expression.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "primaryExpression"

    public static class idVar_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "idVar"
    // parser/Grammerats.g:69:1: idVar : ID -> ^( Id ID ) ;
    public final GrammeratsParser.idVar_return idVar() throws RecognitionException {
        GrammeratsParser.idVar_return retval = new GrammeratsParser.idVar_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token ID36=null;

        Tree ID36_tree=null;
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");

        try {
            // parser/Grammerats.g:69:6: ( ID -> ^( Id ID ) )
            // parser/Grammerats.g:69:8: ID
            {
            ID36=(Token)match(input,ID,FOLLOW_ID_in_idVar695); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ID.add(ID36);



            // AST REWRITE
            // elements: ID
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 69:11: -> ^( Id ID )
            {
                // parser/Grammerats.g:69:14: ^( Id ID )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Id, "Id"), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "idVar"

    public static class divExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "divExpression"
    // parser/Grammerats.g:72:1: divExpression : (e1= primaryExpression ) ( ( '/' e2= primaryExpression )+ -> ^( OpExp $e1 ^( Div ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.divExpression_return divExpression() throws RecognitionException {
        GrammeratsParser.divExpression_return retval = new GrammeratsParser.divExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal37=null;
        GrammeratsParser.primaryExpression_return e1 = null;

        GrammeratsParser.primaryExpression_return e2 = null;


        Tree char_literal37_tree=null;
        RewriteRuleTokenStream stream_63=new RewriteRuleTokenStream(adaptor,"token 63");
        RewriteRuleSubtreeStream stream_primaryExpression=new RewriteRuleSubtreeStream(adaptor,"rule primaryExpression");
        try {
            // parser/Grammerats.g:73:5: ( (e1= primaryExpression ) ( ( '/' e2= primaryExpression )+ -> ^( OpExp $e1 ^( Div ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:73:7: (e1= primaryExpression ) ( ( '/' e2= primaryExpression )+ -> ^( OpExp $e1 ^( Div ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:73:7: (e1= primaryExpression )
            // parser/Grammerats.g:73:8: e1= primaryExpression
            {
            pushFollow(FOLLOW_primaryExpression_in_divExpression726);
            e1=primaryExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_primaryExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:73:32: ( ( '/' e2= primaryExpression )+ -> ^( OpExp $e1 ^( Div ) $e2) | -> ^( $e1) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==63) ) {
                alt12=1;
            }
            else if ( (LA12_0==57||LA12_0==60||LA12_0==62||(LA12_0>=64 && LA12_0<=71)) ) {
                alt12=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // parser/Grammerats.g:73:33: ( '/' e2= primaryExpression )+
                    {
                    // parser/Grammerats.g:73:33: ( '/' e2= primaryExpression )+
                    int cnt11=0;
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( (LA11_0==63) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // parser/Grammerats.g:73:34: '/' e2= primaryExpression
                    	    {
                    	    char_literal37=(Token)match(input,63,FOLLOW_63_in_divExpression731); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_63.add(char_literal37);

                    	    pushFollow(FOLLOW_primaryExpression_in_divExpression737);
                    	    e2=primaryExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_primaryExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt11 >= 1 ) break loop11;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(11, input);
                                throw eee;
                        }
                        cnt11++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 73:62: -> ^( OpExp $e1 ^( Div ) $e2)
                    {
                        // parser/Grammerats.g:73:65: ^( OpExp $e1 ^( Div ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:73:77: ^( Div )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Div, "Div"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:73:91: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 73:91: -> ^( $e1)
                    {
                        // parser/Grammerats.g:73:94: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "divExpression"

    public static class multiplicativeExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicativeExpression"
    // parser/Grammerats.g:76:1: multiplicativeExpression : (e1= divExpression ) ( ( '*' e2= divExpression )+ -> ^( OpExp $e1 ^( Times ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.multiplicativeExpression_return multiplicativeExpression() throws RecognitionException {
        GrammeratsParser.multiplicativeExpression_return retval = new GrammeratsParser.multiplicativeExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal38=null;
        GrammeratsParser.divExpression_return e1 = null;

        GrammeratsParser.divExpression_return e2 = null;


        Tree char_literal38_tree=null;
        RewriteRuleTokenStream stream_64=new RewriteRuleTokenStream(adaptor,"token 64");
        RewriteRuleSubtreeStream stream_divExpression=new RewriteRuleSubtreeStream(adaptor,"rule divExpression");
        try {
            // parser/Grammerats.g:77:9: ( (e1= divExpression ) ( ( '*' e2= divExpression )+ -> ^( OpExp $e1 ^( Times ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:77:13: (e1= divExpression ) ( ( '*' e2= divExpression )+ -> ^( OpExp $e1 ^( Times ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:77:13: (e1= divExpression )
            // parser/Grammerats.g:77:14: e1= divExpression
            {
            pushFollow(FOLLOW_divExpression_in_multiplicativeExpression796);
            e1=divExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_divExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:77:34: ( ( '*' e2= divExpression )+ -> ^( OpExp $e1 ^( Times ) $e2) | -> ^( $e1) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==64) ) {
                alt14=1;
            }
            else if ( (LA14_0==57||LA14_0==60||LA14_0==62||(LA14_0>=65 && LA14_0<=71)) ) {
                alt14=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // parser/Grammerats.g:77:35: ( '*' e2= divExpression )+
                    {
                    // parser/Grammerats.g:77:35: ( '*' e2= divExpression )+
                    int cnt13=0;
                    loop13:
                    do {
                        int alt13=2;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0==64) ) {
                            alt13=1;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // parser/Grammerats.g:77:36: '*' e2= divExpression
                    	    {
                    	    char_literal38=(Token)match(input,64,FOLLOW_64_in_multiplicativeExpression801); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_64.add(char_literal38);

                    	    pushFollow(FOLLOW_divExpression_in_multiplicativeExpression807);
                    	    e2=divExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_divExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt13 >= 1 ) break loop13;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(13, input);
                                throw eee;
                        }
                        cnt13++;
                    } while (true);



                    // AST REWRITE
                    // elements: e1, e2
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 77:62: -> ^( OpExp $e1 ^( Times ) $e2)
                    {
                        // parser/Grammerats.g:77:65: ^( OpExp $e1 ^( Times ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:77:77: ^( Times )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Times, "Times"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:77:93: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 77:93: -> ^( $e1)
                    {
                        // parser/Grammerats.g:77:96: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicativeExpression"

    public static class minusExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "minusExpression"
    // parser/Grammerats.g:80:1: minusExpression : (e1= multiplicativeExpression ) ( ( '-' e2= multiplicativeExpression )+ -> ^( OpExp $e1 ^( Minus ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.minusExpression_return minusExpression() throws RecognitionException {
        GrammeratsParser.minusExpression_return retval = new GrammeratsParser.minusExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal39=null;
        GrammeratsParser.multiplicativeExpression_return e1 = null;

        GrammeratsParser.multiplicativeExpression_return e2 = null;


        Tree char_literal39_tree=null;
        RewriteRuleTokenStream stream_65=new RewriteRuleTokenStream(adaptor,"token 65");
        RewriteRuleSubtreeStream stream_multiplicativeExpression=new RewriteRuleSubtreeStream(adaptor,"rule multiplicativeExpression");
        try {
            // parser/Grammerats.g:81:5: ( (e1= multiplicativeExpression ) ( ( '-' e2= multiplicativeExpression )+ -> ^( OpExp $e1 ^( Minus ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:81:7: (e1= multiplicativeExpression ) ( ( '-' e2= multiplicativeExpression )+ -> ^( OpExp $e1 ^( Minus ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:81:7: (e1= multiplicativeExpression )
            // parser/Grammerats.g:81:8: e1= multiplicativeExpression
            {
            pushFollow(FOLLOW_multiplicativeExpression_in_minusExpression870);
            e1=multiplicativeExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_multiplicativeExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:81:39: ( ( '-' e2= multiplicativeExpression )+ -> ^( OpExp $e1 ^( Minus ) $e2) | -> ^( $e1) )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==65) ) {
                alt16=1;
            }
            else if ( (LA16_0==57||LA16_0==60||LA16_0==62||(LA16_0>=66 && LA16_0<=71)) ) {
                alt16=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // parser/Grammerats.g:81:40: ( '-' e2= multiplicativeExpression )+
                    {
                    // parser/Grammerats.g:81:40: ( '-' e2= multiplicativeExpression )+
                    int cnt15=0;
                    loop15:
                    do {
                        int alt15=2;
                        int LA15_0 = input.LA(1);

                        if ( (LA15_0==65) ) {
                            alt15=1;
                        }


                        switch (alt15) {
                    	case 1 :
                    	    // parser/Grammerats.g:81:41: '-' e2= multiplicativeExpression
                    	    {
                    	    char_literal39=(Token)match(input,65,FOLLOW_65_in_minusExpression875); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_65.add(char_literal39);

                    	    pushFollow(FOLLOW_multiplicativeExpression_in_minusExpression881);
                    	    e2=multiplicativeExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_multiplicativeExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt15 >= 1 ) break loop15;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(15, input);
                                throw eee;
                        }
                        cnt15++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 81:78: -> ^( OpExp $e1 ^( Minus ) $e2)
                    {
                        // parser/Grammerats.g:81:81: ^( OpExp $e1 ^( Minus ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:81:93: ^( Minus )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Minus, "Minus"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:81:109: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 81:109: -> ^( $e1)
                    {
                        // parser/Grammerats.g:81:112: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "minusExpression"

    public static class plusExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "plusExpression"
    // parser/Grammerats.g:84:1: plusExpression : (e1= minusExpression ) ( ( '+' e2= minusExpression )+ -> ^( OpExp $e1 ^( Plus ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.plusExpression_return plusExpression() throws RecognitionException {
        GrammeratsParser.plusExpression_return retval = new GrammeratsParser.plusExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal40=null;
        GrammeratsParser.minusExpression_return e1 = null;

        GrammeratsParser.minusExpression_return e2 = null;


        Tree char_literal40_tree=null;
        RewriteRuleTokenStream stream_66=new RewriteRuleTokenStream(adaptor,"token 66");
        RewriteRuleSubtreeStream stream_minusExpression=new RewriteRuleSubtreeStream(adaptor,"rule minusExpression");
        try {
            // parser/Grammerats.g:85:9: ( (e1= minusExpression ) ( ( '+' e2= minusExpression )+ -> ^( OpExp $e1 ^( Plus ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:85:13: (e1= minusExpression ) ( ( '+' e2= minusExpression )+ -> ^( OpExp $e1 ^( Plus ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:85:13: (e1= minusExpression )
            // parser/Grammerats.g:85:14: e1= minusExpression
            {
            pushFollow(FOLLOW_minusExpression_in_plusExpression938);
            e1=minusExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_minusExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:85:36: ( ( '+' e2= minusExpression )+ -> ^( OpExp $e1 ^( Plus ) $e2) | -> ^( $e1) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==66) ) {
                alt18=1;
            }
            else if ( (LA18_0==57||LA18_0==60||LA18_0==62||(LA18_0>=67 && LA18_0<=71)) ) {
                alt18=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // parser/Grammerats.g:85:37: ( '+' e2= minusExpression )+
                    {
                    // parser/Grammerats.g:85:37: ( '+' e2= minusExpression )+
                    int cnt17=0;
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==66) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // parser/Grammerats.g:85:38: '+' e2= minusExpression
                    	    {
                    	    char_literal40=(Token)match(input,66,FOLLOW_66_in_plusExpression943); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_66.add(char_literal40);

                    	    pushFollow(FOLLOW_minusExpression_in_plusExpression949);
                    	    e2=minusExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_minusExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt17 >= 1 ) break loop17;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(17, input);
                                throw eee;
                        }
                        cnt17++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 85:65: -> ^( OpExp $e1 ^( Plus ) $e2)
                    {
                        // parser/Grammerats.g:85:68: ^( OpExp $e1 ^( Plus ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:85:80: ^( Plus )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Plus, "Plus"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:85:95: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 85:95: -> ^( $e1)
                    {
                        // parser/Grammerats.g:85:97: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "plusExpression"

    public static class lessExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "lessExpression"
    // parser/Grammerats.g:88:1: lessExpression : (e1= plusExpression ) ( ( '<' e2= plusExpression )+ -> ^( OpExp $e1 ^( Less ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.lessExpression_return lessExpression() throws RecognitionException {
        GrammeratsParser.lessExpression_return retval = new GrammeratsParser.lessExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal41=null;
        GrammeratsParser.plusExpression_return e1 = null;

        GrammeratsParser.plusExpression_return e2 = null;


        Tree char_literal41_tree=null;
        RewriteRuleTokenStream stream_67=new RewriteRuleTokenStream(adaptor,"token 67");
        RewriteRuleSubtreeStream stream_plusExpression=new RewriteRuleSubtreeStream(adaptor,"rule plusExpression");
        try {
            // parser/Grammerats.g:89:5: ( (e1= plusExpression ) ( ( '<' e2= plusExpression )+ -> ^( OpExp $e1 ^( Less ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:89:7: (e1= plusExpression ) ( ( '<' e2= plusExpression )+ -> ^( OpExp $e1 ^( Less ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:89:7: (e1= plusExpression )
            // parser/Grammerats.g:89:8: e1= plusExpression
            {
            pushFollow(FOLLOW_plusExpression_in_lessExpression1010);
            e1=plusExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_plusExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:89:29: ( ( '<' e2= plusExpression )+ -> ^( OpExp $e1 ^( Less ) $e2) | -> ^( $e1) )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==67) ) {
                alt20=1;
            }
            else if ( (LA20_0==57||LA20_0==60||LA20_0==62||(LA20_0>=68 && LA20_0<=71)) ) {
                alt20=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // parser/Grammerats.g:89:30: ( '<' e2= plusExpression )+
                    {
                    // parser/Grammerats.g:89:30: ( '<' e2= plusExpression )+
                    int cnt19=0;
                    loop19:
                    do {
                        int alt19=2;
                        int LA19_0 = input.LA(1);

                        if ( (LA19_0==67) ) {
                            alt19=1;
                        }


                        switch (alt19) {
                    	case 1 :
                    	    // parser/Grammerats.g:89:31: '<' e2= plusExpression
                    	    {
                    	    char_literal41=(Token)match(input,67,FOLLOW_67_in_lessExpression1015); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_67.add(char_literal41);

                    	    pushFollow(FOLLOW_plusExpression_in_lessExpression1021);
                    	    e2=plusExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_plusExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt19 >= 1 ) break loop19;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(19, input);
                                throw eee;
                        }
                        cnt19++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 89:58: -> ^( OpExp $e1 ^( Less ) $e2)
                    {
                        // parser/Grammerats.g:89:61: ^( OpExp $e1 ^( Less ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:89:73: ^( Less )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Less, "Less"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:89:88: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 89:88: -> ^( $e1)
                    {
                        // parser/Grammerats.g:89:91: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "lessExpression"

    public static class biggerExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "biggerExpression"
    // parser/Grammerats.g:91:1: biggerExpression : (e1= lessExpression ) ( ( '>' e2= lessExpression )+ -> ^( OpExp $e1 ^( Bigger ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.biggerExpression_return biggerExpression() throws RecognitionException {
        GrammeratsParser.biggerExpression_return retval = new GrammeratsParser.biggerExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token char_literal42=null;
        GrammeratsParser.lessExpression_return e1 = null;

        GrammeratsParser.lessExpression_return e2 = null;


        Tree char_literal42_tree=null;
        RewriteRuleTokenStream stream_68=new RewriteRuleTokenStream(adaptor,"token 68");
        RewriteRuleSubtreeStream stream_lessExpression=new RewriteRuleSubtreeStream(adaptor,"rule lessExpression");
        try {
            // parser/Grammerats.g:92:5: ( (e1= lessExpression ) ( ( '>' e2= lessExpression )+ -> ^( OpExp $e1 ^( Bigger ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:92:7: (e1= lessExpression ) ( ( '>' e2= lessExpression )+ -> ^( OpExp $e1 ^( Bigger ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:92:7: (e1= lessExpression )
            // parser/Grammerats.g:92:8: e1= lessExpression
            {
            pushFollow(FOLLOW_lessExpression_in_biggerExpression1071);
            e1=lessExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_lessExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:92:29: ( ( '>' e2= lessExpression )+ -> ^( OpExp $e1 ^( Bigger ) $e2) | -> ^( $e1) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==68) ) {
                alt22=1;
            }
            else if ( (LA22_0==57||LA22_0==60||LA22_0==62||(LA22_0>=69 && LA22_0<=71)) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // parser/Grammerats.g:92:30: ( '>' e2= lessExpression )+
                    {
                    // parser/Grammerats.g:92:30: ( '>' e2= lessExpression )+
                    int cnt21=0;
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==68) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // parser/Grammerats.g:92:31: '>' e2= lessExpression
                    	    {
                    	    char_literal42=(Token)match(input,68,FOLLOW_68_in_biggerExpression1076); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_68.add(char_literal42);

                    	    pushFollow(FOLLOW_lessExpression_in_biggerExpression1082);
                    	    e2=lessExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_lessExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt21 >= 1 ) break loop21;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(21, input);
                                throw eee;
                        }
                        cnt21++;
                    } while (true);



                    // AST REWRITE
                    // elements: e1, e2
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 92:58: -> ^( OpExp $e1 ^( Bigger ) $e2)
                    {
                        // parser/Grammerats.g:92:61: ^( OpExp $e1 ^( Bigger ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:92:73: ^( Bigger )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Bigger, "Bigger"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:92:90: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 92:90: -> ^( $e1)
                    {
                        // parser/Grammerats.g:92:93: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "biggerExpression"

    public static class diffExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "diffExpression"
    // parser/Grammerats.g:95:1: diffExpression : (e1= biggerExpression ) ( ( '!=' e2= biggerExpression )+ -> ^( OpExp $e1 ^( Diff ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.diffExpression_return diffExpression() throws RecognitionException {
        GrammeratsParser.diffExpression_return retval = new GrammeratsParser.diffExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal43=null;
        GrammeratsParser.biggerExpression_return e1 = null;

        GrammeratsParser.biggerExpression_return e2 = null;


        Tree string_literal43_tree=null;
        RewriteRuleTokenStream stream_69=new RewriteRuleTokenStream(adaptor,"token 69");
        RewriteRuleSubtreeStream stream_biggerExpression=new RewriteRuleSubtreeStream(adaptor,"rule biggerExpression");
        try {
            // parser/Grammerats.g:96:5: ( (e1= biggerExpression ) ( ( '!=' e2= biggerExpression )+ -> ^( OpExp $e1 ^( Diff ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:96:7: (e1= biggerExpression ) ( ( '!=' e2= biggerExpression )+ -> ^( OpExp $e1 ^( Diff ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:96:7: (e1= biggerExpression )
            // parser/Grammerats.g:96:8: e1= biggerExpression
            {
            pushFollow(FOLLOW_biggerExpression_in_diffExpression1133);
            e1=biggerExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_biggerExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:96:31: ( ( '!=' e2= biggerExpression )+ -> ^( OpExp $e1 ^( Diff ) $e2) | -> ^( $e1) )
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==69) ) {
                alt24=1;
            }
            else if ( (LA24_0==57||LA24_0==60||LA24_0==62||(LA24_0>=70 && LA24_0<=71)) ) {
                alt24=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 24, 0, input);

                throw nvae;
            }
            switch (alt24) {
                case 1 :
                    // parser/Grammerats.g:96:32: ( '!=' e2= biggerExpression )+
                    {
                    // parser/Grammerats.g:96:32: ( '!=' e2= biggerExpression )+
                    int cnt23=0;
                    loop23:
                    do {
                        int alt23=2;
                        int LA23_0 = input.LA(1);

                        if ( (LA23_0==69) ) {
                            alt23=1;
                        }


                        switch (alt23) {
                    	case 1 :
                    	    // parser/Grammerats.g:96:33: '!=' e2= biggerExpression
                    	    {
                    	    string_literal43=(Token)match(input,69,FOLLOW_69_in_diffExpression1138); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_69.add(string_literal43);

                    	    pushFollow(FOLLOW_biggerExpression_in_diffExpression1144);
                    	    e2=biggerExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_biggerExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt23 >= 1 ) break loop23;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(23, input);
                                throw eee;
                        }
                        cnt23++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 96:62: -> ^( OpExp $e1 ^( Diff ) $e2)
                    {
                        // parser/Grammerats.g:96:65: ^( OpExp $e1 ^( Diff ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:96:77: ^( Diff )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Diff, "Diff"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:96:92: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 96:92: -> ^( $e1)
                    {
                        // parser/Grammerats.g:96:95: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "diffExpression"

    public static class equalityExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "equalityExpression"
    // parser/Grammerats.g:99:1: equalityExpression : (e1= diffExpression ) ( ( '==' e2= diffExpression )+ -> ^( OpExp $e1 ^( Equal ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.equalityExpression_return equalityExpression() throws RecognitionException {
        GrammeratsParser.equalityExpression_return retval = new GrammeratsParser.equalityExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal44=null;
        GrammeratsParser.diffExpression_return e1 = null;

        GrammeratsParser.diffExpression_return e2 = null;


        Tree string_literal44_tree=null;
        RewriteRuleTokenStream stream_70=new RewriteRuleTokenStream(adaptor,"token 70");
        RewriteRuleSubtreeStream stream_diffExpression=new RewriteRuleSubtreeStream(adaptor,"rule diffExpression");
        try {
            // parser/Grammerats.g:100:9: ( (e1= diffExpression ) ( ( '==' e2= diffExpression )+ -> ^( OpExp $e1 ^( Equal ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:100:13: (e1= diffExpression ) ( ( '==' e2= diffExpression )+ -> ^( OpExp $e1 ^( Equal ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:100:13: (e1= diffExpression )
            // parser/Grammerats.g:100:14: e1= diffExpression
            {
            pushFollow(FOLLOW_diffExpression_in_equalityExpression1200);
            e1=diffExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_diffExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:100:35: ( ( '==' e2= diffExpression )+ -> ^( OpExp $e1 ^( Equal ) $e2) | -> ^( $e1) )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==70) ) {
                alt26=1;
            }
            else if ( (LA26_0==57||LA26_0==60||LA26_0==62||LA26_0==71) ) {
                alt26=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // parser/Grammerats.g:100:36: ( '==' e2= diffExpression )+
                    {
                    // parser/Grammerats.g:100:36: ( '==' e2= diffExpression )+
                    int cnt25=0;
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==70) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // parser/Grammerats.g:100:37: '==' e2= diffExpression
                    	    {
                    	    string_literal44=(Token)match(input,70,FOLLOW_70_in_equalityExpression1205); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_70.add(string_literal44);

                    	    pushFollow(FOLLOW_diffExpression_in_equalityExpression1211);
                    	    e2=diffExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_diffExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt25 >= 1 ) break loop25;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(25, input);
                                throw eee;
                        }
                        cnt25++;
                    } while (true);



                    // AST REWRITE
                    // elements: e2, e1
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 100:66: -> ^( OpExp $e1 ^( Equal ) $e2)
                    {
                        // parser/Grammerats.g:100:69: ^( OpExp $e1 ^( Equal ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:100:81: ^( Equal )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(Equal, "Equal"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:100:97: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 100:97: -> ^( $e1)
                    {
                        // parser/Grammerats.g:100:100: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "equalityExpression"

    public static class logicalAndExpression_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logicalAndExpression"
    // parser/Grammerats.g:103:1: logicalAndExpression : (e1= equalityExpression ) ( ( '&&' e2= equalityExpression )+ -> ^( OpExp $e1 ^( And ) $e2) | -> ^( $e1) ) ;
    public final GrammeratsParser.logicalAndExpression_return logicalAndExpression() throws RecognitionException {
        GrammeratsParser.logicalAndExpression_return retval = new GrammeratsParser.logicalAndExpression_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal45=null;
        GrammeratsParser.equalityExpression_return e1 = null;

        GrammeratsParser.equalityExpression_return e2 = null;


        Tree string_literal45_tree=null;
        RewriteRuleTokenStream stream_71=new RewriteRuleTokenStream(adaptor,"token 71");
        RewriteRuleSubtreeStream stream_equalityExpression=new RewriteRuleSubtreeStream(adaptor,"rule equalityExpression");
        try {
            // parser/Grammerats.g:104:9: ( (e1= equalityExpression ) ( ( '&&' e2= equalityExpression )+ -> ^( OpExp $e1 ^( And ) $e2) | -> ^( $e1) ) )
            // parser/Grammerats.g:104:13: (e1= equalityExpression ) ( ( '&&' e2= equalityExpression )+ -> ^( OpExp $e1 ^( And ) $e2) | -> ^( $e1) )
            {
            // parser/Grammerats.g:104:13: (e1= equalityExpression )
            // parser/Grammerats.g:104:14: e1= equalityExpression
            {
            pushFollow(FOLLOW_equalityExpression_in_logicalAndExpression1273);
            e1=equalityExpression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_equalityExpression.add(e1.getTree());

            }

            // parser/Grammerats.g:104:39: ( ( '&&' e2= equalityExpression )+ -> ^( OpExp $e1 ^( And ) $e2) | -> ^( $e1) )
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==71) ) {
                alt28=1;
            }
            else if ( (LA28_0==57||LA28_0==60||LA28_0==62) ) {
                alt28=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }
            switch (alt28) {
                case 1 :
                    // parser/Grammerats.g:104:40: ( '&&' e2= equalityExpression )+
                    {
                    // parser/Grammerats.g:104:40: ( '&&' e2= equalityExpression )+
                    int cnt27=0;
                    loop27:
                    do {
                        int alt27=2;
                        int LA27_0 = input.LA(1);

                        if ( (LA27_0==71) ) {
                            alt27=1;
                        }


                        switch (alt27) {
                    	case 1 :
                    	    // parser/Grammerats.g:104:41: '&&' e2= equalityExpression
                    	    {
                    	    string_literal45=(Token)match(input,71,FOLLOW_71_in_logicalAndExpression1278); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_71.add(string_literal45);

                    	    pushFollow(FOLLOW_equalityExpression_in_logicalAndExpression1284);
                    	    e2=equalityExpression();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_equalityExpression.add(e2.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt27 >= 1 ) break loop27;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(27, input);
                                throw eee;
                        }
                        cnt27++;
                    } while (true);



                    // AST REWRITE
                    // elements: e1, e2
                    // token labels: 
                    // rule labels: retval, e1, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 104:74: -> ^( OpExp $e1 ^( And ) $e2)
                    {
                        // parser/Grammerats.g:104:77: ^( OpExp $e1 ^( And ) $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(OpExp, "OpExp"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());
                        // parser/Grammerats.g:104:89: ^( And )
                        {
                        Tree root_2 = (Tree)adaptor.nil();
                        root_2 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(And, "And"), root_2);

                        adaptor.addChild(root_1, root_2);
                        }
                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:104:103: 
                    {

                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 104:103: -> ^( $e1)
                    {
                        // parser/Grammerats.g:104:106: ^( $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot(stream_e1.nextNode(), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logicalAndExpression"

    public static class selection_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "selection"
    // parser/Grammerats.g:107:1: selection : 'if' '(' s0= expression ')' 'then' s1= statements ( ( 'else' )=> 'else' s2= statements -> ^( IfElse $s0 $s1 $s2) | -> ^( IfStatement $s0 $s1) ) ;
    public final GrammeratsParser.selection_return selection() throws RecognitionException {
        GrammeratsParser.selection_return retval = new GrammeratsParser.selection_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal46=null;
        Token char_literal47=null;
        Token char_literal48=null;
        Token string_literal49=null;
        Token string_literal50=null;
        GrammeratsParser.expression_return s0 = null;

        GrammeratsParser.statements_return s1 = null;

        GrammeratsParser.statements_return s2 = null;


        Tree string_literal46_tree=null;
        Tree char_literal47_tree=null;
        Tree char_literal48_tree=null;
        Tree string_literal49_tree=null;
        Tree string_literal50_tree=null;
        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
        RewriteRuleTokenStream stream_72=new RewriteRuleTokenStream(adaptor,"token 72");
        RewriteRuleTokenStream stream_73=new RewriteRuleTokenStream(adaptor,"token 73");
        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
        RewriteRuleTokenStream stream_74=new RewriteRuleTokenStream(adaptor,"token 74");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_statements=new RewriteRuleSubtreeStream(adaptor,"rule statements");
        try {
            // parser/Grammerats.g:108:5: ( 'if' '(' s0= expression ')' 'then' s1= statements ( ( 'else' )=> 'else' s2= statements -> ^( IfElse $s0 $s1 $s2) | -> ^( IfStatement $s0 $s1) ) )
            // parser/Grammerats.g:108:7: 'if' '(' s0= expression ')' 'then' s1= statements ( ( 'else' )=> 'else' s2= statements -> ^( IfElse $s0 $s1 $s2) | -> ^( IfStatement $s0 $s1) )
            {
            string_literal46=(Token)match(input,72,FOLLOW_72_in_selection1343); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_72.add(string_literal46);

            char_literal47=(Token)match(input,61,FOLLOW_61_in_selection1345); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_61.add(char_literal47);

            pushFollow(FOLLOW_expression_in_selection1349);
            s0=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(s0.getTree());
            char_literal48=(Token)match(input,62,FOLLOW_62_in_selection1351); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_62.add(char_literal48);

            string_literal49=(Token)match(input,73,FOLLOW_73_in_selection1353); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_73.add(string_literal49);

            pushFollow(FOLLOW_statements_in_selection1357);
            s1=statements();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_statements.add(s1.getTree());
            // parser/Grammerats.g:108:55: ( ( 'else' )=> 'else' s2= statements -> ^( IfElse $s0 $s1 $s2) | -> ^( IfStatement $s0 $s1) )
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==74) ) {
                int LA29_1 = input.LA(2);

                if ( (synpred1_Grammerats()) ) {
                    alt29=1;
                }
                else if ( (true) ) {
                    alt29=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 29, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA29_0==EOF||LA29_0==ID||(LA29_0>=53 && LA29_0<=54)||LA29_0==56||LA29_0==72||(LA29_0>=75 && LA29_0<=82)) ) {
                alt29=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }
            switch (alt29) {
                case 1 :
                    // parser/Grammerats.g:108:56: ( 'else' )=> 'else' s2= statements
                    {
                    string_literal50=(Token)match(input,74,FOLLOW_74_in_selection1364); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_74.add(string_literal50);

                    pushFollow(FOLLOW_statements_in_selection1370);
                    s2=statements();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statements.add(s2.getTree());


                    // AST REWRITE
                    // elements: s1, s0, s2
                    // token labels: 
                    // rule labels: s0, retval, s2, s1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_s0=new RewriteRuleSubtreeStream(adaptor,"rule s0",s0!=null?s0.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);
                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 108:89: -> ^( IfElse $s0 $s1 $s2)
                    {
                        // parser/Grammerats.g:108:92: ^( IfElse $s0 $s1 $s2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(IfElse, "IfElse"), root_1);

                        adaptor.addChild(root_1, stream_s0.nextTree());
                        adaptor.addChild(root_1, stream_s1.nextTree());
                        adaptor.addChild(root_1, stream_s2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:109:58: 
                    {

                    // AST REWRITE
                    // elements: s0, s1
                    // token labels: 
                    // rule labels: s0, retval, s1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_s0=new RewriteRuleSubtreeStream(adaptor,"rule s0",s0!=null?s0.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s1=new RewriteRuleSubtreeStream(adaptor,"rule s1",s1!=null?s1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 109:58: -> ^( IfStatement $s0 $s1)
                    {
                        // parser/Grammerats.g:109:61: ^( IfStatement $s0 $s1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(IfStatement, "IfStatement"), root_1);

                        adaptor.addChild(root_1, stream_s0.nextTree());
                        adaptor.addChild(root_1, stream_s1.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "selection"

    public static class iteration_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "iteration"
    // parser/Grammerats.g:112:1: iteration : ( 'while' '(' expression ')' statements -> ^( WhileStatement expression statements ) | 'for' '(' forInit ';' expression ';' assignment ')' statements -> ^( ForStatement forInit expression assignment statements ) );
    public final GrammeratsParser.iteration_return iteration() throws RecognitionException {
        GrammeratsParser.iteration_return retval = new GrammeratsParser.iteration_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal51=null;
        Token char_literal52=null;
        Token char_literal54=null;
        Token string_literal56=null;
        Token char_literal57=null;
        Token char_literal59=null;
        Token char_literal61=null;
        Token char_literal63=null;
        GrammeratsParser.expression_return expression53 = null;

        GrammeratsParser.statements_return statements55 = null;

        GrammeratsParser.forInit_return forInit58 = null;

        GrammeratsParser.expression_return expression60 = null;

        GrammeratsParser.assignment_return assignment62 = null;

        GrammeratsParser.statements_return statements64 = null;


        Tree string_literal51_tree=null;
        Tree char_literal52_tree=null;
        Tree char_literal54_tree=null;
        Tree string_literal56_tree=null;
        Tree char_literal57_tree=null;
        Tree char_literal59_tree=null;
        Tree char_literal61_tree=null;
        Tree char_literal63_tree=null;
        RewriteRuleTokenStream stream_57=new RewriteRuleTokenStream(adaptor,"token 57");
        RewriteRuleTokenStream stream_62=new RewriteRuleTokenStream(adaptor,"token 62");
        RewriteRuleTokenStream stream_61=new RewriteRuleTokenStream(adaptor,"token 61");
        RewriteRuleTokenStream stream_75=new RewriteRuleTokenStream(adaptor,"token 75");
        RewriteRuleTokenStream stream_76=new RewriteRuleTokenStream(adaptor,"token 76");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        RewriteRuleSubtreeStream stream_assignment=new RewriteRuleSubtreeStream(adaptor,"rule assignment");
        RewriteRuleSubtreeStream stream_statements=new RewriteRuleSubtreeStream(adaptor,"rule statements");
        RewriteRuleSubtreeStream stream_forInit=new RewriteRuleSubtreeStream(adaptor,"rule forInit");
        try {
            // parser/Grammerats.g:113:5: ( 'while' '(' expression ')' statements -> ^( WhileStatement expression statements ) | 'for' '(' forInit ';' expression ';' assignment ')' statements -> ^( ForStatement forInit expression assignment statements ) )
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==75) ) {
                alt30=1;
            }
            else if ( (LA30_0==76) ) {
                alt30=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }
            switch (alt30) {
                case 1 :
                    // parser/Grammerats.g:113:7: 'while' '(' expression ')' statements
                    {
                    string_literal51=(Token)match(input,75,FOLLOW_75_in_iteration1476); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_75.add(string_literal51);

                    char_literal52=(Token)match(input,61,FOLLOW_61_in_iteration1478); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_61.add(char_literal52);

                    pushFollow(FOLLOW_expression_in_iteration1480);
                    expression53=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression53.getTree());
                    char_literal54=(Token)match(input,62,FOLLOW_62_in_iteration1482); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_62.add(char_literal54);

                    pushFollow(FOLLOW_statements_in_iteration1484);
                    statements55=statements();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statements.add(statements55.getTree());


                    // AST REWRITE
                    // elements: statements, expression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 113:47: -> ^( WhileStatement expression statements )
                    {
                        // parser/Grammerats.g:113:51: ^( WhileStatement expression statements )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(WhileStatement, "WhileStatement"), root_1);

                        adaptor.addChild(root_1, stream_expression.nextTree());
                        adaptor.addChild(root_1, stream_statements.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:114:7: 'for' '(' forInit ';' expression ';' assignment ')' statements
                    {
                    string_literal56=(Token)match(input,76,FOLLOW_76_in_iteration1505); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_76.add(string_literal56);

                    char_literal57=(Token)match(input,61,FOLLOW_61_in_iteration1507); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_61.add(char_literal57);

                    pushFollow(FOLLOW_forInit_in_iteration1509);
                    forInit58=forInit();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_forInit.add(forInit58.getTree());
                    char_literal59=(Token)match(input,57,FOLLOW_57_in_iteration1511); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_57.add(char_literal59);

                    pushFollow(FOLLOW_expression_in_iteration1513);
                    expression60=expression();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expression.add(expression60.getTree());
                    char_literal61=(Token)match(input,57,FOLLOW_57_in_iteration1515); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_57.add(char_literal61);

                    pushFollow(FOLLOW_assignment_in_iteration1518);
                    assignment62=assignment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment.add(assignment62.getTree());
                    char_literal63=(Token)match(input,62,FOLLOW_62_in_iteration1520); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_62.add(char_literal63);

                    pushFollow(FOLLOW_statements_in_iteration1522);
                    statements64=statements();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_statements.add(statements64.getTree());


                    // AST REWRITE
                    // elements: forInit, assignment, expression, statements
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 114:71: -> ^( ForStatement forInit expression assignment statements )
                    {
                        // parser/Grammerats.g:114:74: ^( ForStatement forInit expression assignment statements )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ForStatement, "ForStatement"), root_1);

                        adaptor.addChild(root_1, stream_forInit.nextTree());
                        adaptor.addChild(root_1, stream_expression.nextTree());
                        adaptor.addChild(root_1, stream_assignment.nextTree());
                        adaptor.addChild(root_1, stream_statements.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "iteration"

    public static class forInit_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forInit"
    // parser/Grammerats.g:117:1: forInit : ( (e1= assignment -> ^( AtribF $e1) ) | (e2= assignmentDeclaration -> ^( InitF $e2) ) ) ;
    public final GrammeratsParser.forInit_return forInit() throws RecognitionException {
        GrammeratsParser.forInit_return retval = new GrammeratsParser.forInit_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        GrammeratsParser.assignment_return e1 = null;

        GrammeratsParser.assignmentDeclaration_return e2 = null;


        RewriteRuleSubtreeStream stream_assignment=new RewriteRuleSubtreeStream(adaptor,"rule assignment");
        RewriteRuleSubtreeStream stream_assignmentDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule assignmentDeclaration");
        try {
            // parser/Grammerats.g:117:9: ( ( (e1= assignment -> ^( AtribF $e1) ) | (e2= assignmentDeclaration -> ^( InitF $e2) ) ) )
            // parser/Grammerats.g:117:11: ( (e1= assignment -> ^( AtribF $e1) ) | (e2= assignmentDeclaration -> ^( InitF $e2) ) )
            {
            // parser/Grammerats.g:117:11: ( (e1= assignment -> ^( AtribF $e1) ) | (e2= assignmentDeclaration -> ^( InitF $e2) ) )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==ID) ) {
                alt31=1;
            }
            else if ( ((LA31_0>=78 && LA31_0<=82)) ) {
                alt31=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // parser/Grammerats.g:117:12: (e1= assignment -> ^( AtribF $e1) )
                    {
                    // parser/Grammerats.g:117:12: (e1= assignment -> ^( AtribF $e1) )
                    // parser/Grammerats.g:117:13: e1= assignment
                    {
                    pushFollow(FOLLOW_assignment_in_forInit1553);
                    e1=assignment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignment.add(e1.getTree());


                    // AST REWRITE
                    // elements: e1
                    // token labels: 
                    // rule labels: retval, e1
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e1=new RewriteRuleSubtreeStream(adaptor,"rule e1",e1!=null?e1.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 117:27: -> ^( AtribF $e1)
                    {
                        // parser/Grammerats.g:117:30: ^( AtribF $e1)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(AtribF, "AtribF"), root_1);

                        adaptor.addChild(root_1, stream_e1.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:117:47: (e2= assignmentDeclaration -> ^( InitF $e2) )
                    {
                    // parser/Grammerats.g:117:47: (e2= assignmentDeclaration -> ^( InitF $e2) )
                    // parser/Grammerats.g:117:48: e2= assignmentDeclaration
                    {
                    pushFollow(FOLLOW_assignmentDeclaration_in_forInit1570);
                    e2=assignmentDeclaration();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_assignmentDeclaration.add(e2.getTree());


                    // AST REWRITE
                    // elements: e2
                    // token labels: 
                    // rule labels: retval, e2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_e2=new RewriteRuleSubtreeStream(adaptor,"rule e2",e2!=null?e2.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 117:73: -> ^( InitF $e2)
                    {
                        // parser/Grammerats.g:117:75: ^( InitF $e2)
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(InitF, "InitF"), root_1);

                        adaptor.addChild(root_1, stream_e2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }


                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forInit"

    public static class stReturn_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stReturn"
    // parser/Grammerats.g:120:1: stReturn : 'return' expression -> ^( ReturnStatement expression ) ;
    public final GrammeratsParser.stReturn_return stReturn() throws RecognitionException {
        GrammeratsParser.stReturn_return retval = new GrammeratsParser.stReturn_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal65=null;
        GrammeratsParser.expression_return expression66 = null;


        Tree string_literal65_tree=null;
        RewriteRuleTokenStream stream_77=new RewriteRuleTokenStream(adaptor,"token 77");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // parser/Grammerats.g:121:5: ( 'return' expression -> ^( ReturnStatement expression ) )
            // parser/Grammerats.g:121:7: 'return' expression
            {
            string_literal65=(Token)match(input,77,FOLLOW_77_in_stReturn1609); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_77.add(string_literal65);

            pushFollow(FOLLOW_expression_in_stReturn1611);
            expression66=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression66.getTree());


            // AST REWRITE
            // elements: expression
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Tree)adaptor.nil();
            // 121:28: -> ^( ReturnStatement expression )
            {
                // parser/Grammerats.g:121:32: ^( ReturnStatement expression )
                {
                Tree root_1 = (Tree)adaptor.nil();
                root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(ReturnStatement, "ReturnStatement"), root_1);

                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stReturn"

    public static class type_return extends ParserRuleReturnScope {
        Tree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // parser/Grammerats.g:125:1: type : ( 'void' -> ^( TypeVoid ) | 'int' -> ^( TypeInt ) | 'char' -> ^( TypeChar ) | 'float' -> ^( TypeFloat ) | 'double' -> ^( TypeDouble ) );
    public final GrammeratsParser.type_return type() throws RecognitionException {
        GrammeratsParser.type_return retval = new GrammeratsParser.type_return();
        retval.start = input.LT(1);

        Tree root_0 = null;

        Token string_literal67=null;
        Token string_literal68=null;
        Token string_literal69=null;
        Token string_literal70=null;
        Token string_literal71=null;

        Tree string_literal67_tree=null;
        Tree string_literal68_tree=null;
        Tree string_literal69_tree=null;
        Tree string_literal70_tree=null;
        Tree string_literal71_tree=null;
        RewriteRuleTokenStream stream_79=new RewriteRuleTokenStream(adaptor,"token 79");
        RewriteRuleTokenStream stream_78=new RewriteRuleTokenStream(adaptor,"token 78");
        RewriteRuleTokenStream stream_82=new RewriteRuleTokenStream(adaptor,"token 82");
        RewriteRuleTokenStream stream_80=new RewriteRuleTokenStream(adaptor,"token 80");
        RewriteRuleTokenStream stream_81=new RewriteRuleTokenStream(adaptor,"token 81");

        try {
            // parser/Grammerats.g:125:6: ( 'void' -> ^( TypeVoid ) | 'int' -> ^( TypeInt ) | 'char' -> ^( TypeChar ) | 'float' -> ^( TypeFloat ) | 'double' -> ^( TypeDouble ) )
            int alt32=5;
            switch ( input.LA(1) ) {
            case 78:
                {
                alt32=1;
                }
                break;
            case 79:
                {
                alt32=2;
                }
                break;
            case 80:
                {
                alt32=3;
                }
                break;
            case 81:
                {
                alt32=4;
                }
                break;
            case 82:
                {
                alt32=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }

            switch (alt32) {
                case 1 :
                    // parser/Grammerats.g:125:8: 'void'
                    {
                    string_literal67=(Token)match(input,78,FOLLOW_78_in_type1635); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_78.add(string_literal67);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 125:15: -> ^( TypeVoid )
                    {
                        // parser/Grammerats.g:125:17: ^( TypeVoid )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeVoid, "TypeVoid"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:126:8: 'int'
                    {
                    string_literal68=(Token)match(input,79,FOLLOW_79_in_type1649); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_79.add(string_literal68);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 126:14: -> ^( TypeInt )
                    {
                        // parser/Grammerats.g:126:16: ^( TypeInt )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeInt, "TypeInt"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // parser/Grammerats.g:127:8: 'char'
                    {
                    string_literal69=(Token)match(input,80,FOLLOW_80_in_type1663); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_80.add(string_literal69);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 127:15: -> ^( TypeChar )
                    {
                        // parser/Grammerats.g:127:17: ^( TypeChar )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeChar, "TypeChar"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 4 :
                    // parser/Grammerats.g:128:8: 'float'
                    {
                    string_literal70=(Token)match(input,81,FOLLOW_81_in_type1677); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_81.add(string_literal70);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 128:16: -> ^( TypeFloat )
                    {
                        // parser/Grammerats.g:128:18: ^( TypeFloat )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeFloat, "TypeFloat"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 5 :
                    // parser/Grammerats.g:129:8: 'double'
                    {
                    string_literal71=(Token)match(input,82,FOLLOW_82_in_type1691); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_82.add(string_literal71);



                    // AST REWRITE
                    // elements: 
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Tree)adaptor.nil();
                    // 129:17: -> ^( TypeDouble )
                    {
                        // parser/Grammerats.g:129:19: ^( TypeDouble )
                        {
                        Tree root_1 = (Tree)adaptor.nil();
                        root_1 = (Tree)adaptor.becomeRoot((Tree)adaptor.create(TypeDouble, "TypeDouble"), root_1);

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Tree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Tree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    // $ANTLR start synpred1_Grammerats
    public final void synpred1_Grammerats_fragment() throws RecognitionException {   
        // parser/Grammerats.g:108:56: ( 'else' )
        // parser/Grammerats.g:108:57: 'else'
        {
        match(input,74,FOLLOW_74_in_synpred1_Grammerats1361); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_Grammerats

    // Delegated rules

    public final boolean synpred1_Grammerats() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_Grammerats_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


 

    public static final BitSet FOLLOW_program_in_programs58 = new BitSet(new long[]{0x0060000000000000L});
    public static final BitSet FOLLOW_EOF_in_programs61 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_53_in_program92 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_54_in_program96 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_idVar_in_program99 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statements_in_program101 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_55_in_statements145 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statement_in_statements147 = new BitSet(new long[]{0x0184000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_56_in_statements150 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_statements177 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_declaration_in_statement218 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_57_in_statement220 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_in_statement239 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_57_in_statement241 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_selection_in_statement261 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_iteration_in_statement286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_stReturn_in_statement311 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_57_in_statement313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleDeclaration_in_declaration347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignmentDeclaration_in_declaration368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_simpleDeclaration399 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_varlist_in_simpleDeclaration401 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_idVar_in_varlist429 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_58_in_varlist432 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_idVar_in_varlist434 = new BitSet(new long[]{0x0400000000000002L});
    public static final BitSet FOLLOW_type_in_assignmentDeclaration467 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_assignment_in_assignmentDeclaration469 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_idVar_in_assignment503 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_59_in_assignment505 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_assignment507 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_logicalAndExpression_in_expression550 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_60_in_expression555 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_logicalAndExpression_in_expression561 = new BitSet(new long[]{0x1000000000000002L});
    public static final BitSet FOLLOW_ID_in_primaryExpression615 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INT_in_primaryExpression638 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_61_in_primaryExpression669 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_primaryExpression671 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_62_in_primaryExpression673 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_idVar695 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primaryExpression_in_divExpression726 = new BitSet(new long[]{0x8000000000000002L});
    public static final BitSet FOLLOW_63_in_divExpression731 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_primaryExpression_in_divExpression737 = new BitSet(new long[]{0x8000000000000002L});
    public static final BitSet FOLLOW_divExpression_in_multiplicativeExpression796 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_64_in_multiplicativeExpression801 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_divExpression_in_multiplicativeExpression807 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_minusExpression870 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000002L});
    public static final BitSet FOLLOW_65_in_minusExpression875 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_minusExpression881 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000002L});
    public static final BitSet FOLLOW_minusExpression_in_plusExpression938 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_66_in_plusExpression943 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_minusExpression_in_plusExpression949 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_plusExpression_in_lessExpression1010 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_67_in_lessExpression1015 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_plusExpression_in_lessExpression1021 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L});
    public static final BitSet FOLLOW_lessExpression_in_biggerExpression1071 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L});
    public static final BitSet FOLLOW_68_in_biggerExpression1076 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_lessExpression_in_biggerExpression1082 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000010L});
    public static final BitSet FOLLOW_biggerExpression_in_diffExpression1133 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000020L});
    public static final BitSet FOLLOW_69_in_diffExpression1138 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_biggerExpression_in_diffExpression1144 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000020L});
    public static final BitSet FOLLOW_diffExpression_in_equalityExpression1200 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_70_in_equalityExpression1205 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_diffExpression_in_equalityExpression1211 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_equalityExpression_in_logicalAndExpression1273 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000080L});
    public static final BitSet FOLLOW_71_in_logicalAndExpression1278 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_equalityExpression_in_logicalAndExpression1284 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000080L});
    public static final BitSet FOLLOW_72_in_selection1343 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_selection1345 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_selection1349 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_62_in_selection1351 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_73_in_selection1353 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statements_in_selection1357 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000400L});
    public static final BitSet FOLLOW_74_in_selection1364 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statements_in_selection1370 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_75_in_iteration1476 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_iteration1478 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_iteration1480 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_62_in_iteration1482 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statements_in_iteration1484 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_76_in_iteration1505 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_61_in_iteration1507 = new BitSet(new long[]{0x0004000000000000L,0x000000000007C000L});
    public static final BitSet FOLLOW_forInit_in_iteration1509 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_57_in_iteration1511 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_iteration1513 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_57_in_iteration1515 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_assignment_in_iteration1518 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_62_in_iteration1520 = new BitSet(new long[]{0x0084000000000000L,0x000000000007F900L});
    public static final BitSet FOLLOW_statements_in_iteration1522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_in_forInit1553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignmentDeclaration_in_forInit1570 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_77_in_stReturn1609 = new BitSet(new long[]{0x200C000000000000L});
    public static final BitSet FOLLOW_expression_in_stReturn1611 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_78_in_type1635 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_79_in_type1649 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_80_in_type1663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_81_in_type1677 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_82_in_type1691 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_74_in_synpred1_Grammerats1361 = new BitSet(new long[]{0x0000000000000002L});

}