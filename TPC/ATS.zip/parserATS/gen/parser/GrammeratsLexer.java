// $ANTLR 3.2 Sep 23, 2009 12:02:23 parser/Grammerats.g 2016-10-26 18:01:57

  package parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class GrammeratsLexer extends Lexer {
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int T__66=66;
    public static final int T__67=67;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int Bigger=17;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int Diff=18;
    public static final int WhileStatement=37;
    public static final int TypeDouble=39;
    public static final int TypeInt=42;
    public static final int T__61=61;
    public static final int ID=50;
    public static final int EOF=-1;
    public static final int T__60=60;
    public static final int ForStatement=36;
    public static final int Program=22;
    public static final int Int=29;
    public static final int StmList=23;
    public static final int T__55=55;
    public static final int StatementIteration=32;
    public static final int T__56=56;
    public static final int InitF=11;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__53=53;
    public static final int AtribF=10;
    public static final int T__54=54;
    public static final int Declaration=38;
    public static final int Less=16;
    public static final int T__59=59;
    public static final int IfElse=49;
    public static final int TypeChar=41;
    public static final int ListProgram=26;
    public static final int ReturnStatement=46;
    public static final int Or=21;
    public static final int IdVar=28;
    public static final int Id=27;
    public static final int And=20;
    public static final int Div=12;
    public static final int SimpleDeclaration=45;
    public static final int T__80=80;
    public static final int StatementDeclaration=35;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int Assignment=25;
    public static final int StatementAssignment=34;
    public static final int StatementReturn=31;
    public static final int INT=51;
    public static final int Equal=19;
    public static final int Plus=15;
    public static final int OpExp=30;
    public static final int Minus=14;
    public static final int T__71=71;
    public static final int WS=52;
    public static final int T__72=72;
    public static final int T__70=70;
    public static final int Times=13;
    public static final int TypeVoid=43;
    public static final int AssignmentDeclaration=44;
    public static final int VarList=24;
    public static final int IfStatement=48;
    public static final int T__76=76;
    public static final int TypeFloat=40;
    public static final int T__75=75;
    public static final int T__74=74;
    public static final int T__73=73;
    public static final int DeclarationAssignment=47;
    public static final int T__79=79;
    public static final int T__78=78;
    public static final int StatementSelection=33;
    public static final int T__77=77;

    // delegates
    // delegators

    public GrammeratsLexer() {;} 
    public GrammeratsLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public GrammeratsLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "parser/Grammerats.g"; }

    // $ANTLR start "T__53"
    public final void mT__53() throws RecognitionException {
        try {
            int _type = T__53;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:11:7: ( 'Program' )
            // parser/Grammerats.g:11:9: 'Program'
            {
            match("Program"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__53"

    // $ANTLR start "T__54"
    public final void mT__54() throws RecognitionException {
        try {
            int _type = T__54;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:12:7: ( 'program' )
            // parser/Grammerats.g:12:9: 'program'
            {
            match("program"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__54"

    // $ANTLR start "T__55"
    public final void mT__55() throws RecognitionException {
        try {
            int _type = T__55;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:13:7: ( '{' )
            // parser/Grammerats.g:13:9: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__55"

    // $ANTLR start "T__56"
    public final void mT__56() throws RecognitionException {
        try {
            int _type = T__56;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:14:7: ( '}' )
            // parser/Grammerats.g:14:9: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__56"

    // $ANTLR start "T__57"
    public final void mT__57() throws RecognitionException {
        try {
            int _type = T__57;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:15:7: ( ';' )
            // parser/Grammerats.g:15:9: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__57"

    // $ANTLR start "T__58"
    public final void mT__58() throws RecognitionException {
        try {
            int _type = T__58;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:16:7: ( ',' )
            // parser/Grammerats.g:16:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__58"

    // $ANTLR start "T__59"
    public final void mT__59() throws RecognitionException {
        try {
            int _type = T__59;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:17:7: ( '=' )
            // parser/Grammerats.g:17:9: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__59"

    // $ANTLR start "T__60"
    public final void mT__60() throws RecognitionException {
        try {
            int _type = T__60;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:18:7: ( '||' )
            // parser/Grammerats.g:18:9: '||'
            {
            match("||"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__60"

    // $ANTLR start "T__61"
    public final void mT__61() throws RecognitionException {
        try {
            int _type = T__61;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:19:7: ( '(' )
            // parser/Grammerats.g:19:9: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__61"

    // $ANTLR start "T__62"
    public final void mT__62() throws RecognitionException {
        try {
            int _type = T__62;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:20:7: ( ')' )
            // parser/Grammerats.g:20:9: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__62"

    // $ANTLR start "T__63"
    public final void mT__63() throws RecognitionException {
        try {
            int _type = T__63;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:21:7: ( '/' )
            // parser/Grammerats.g:21:9: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__63"

    // $ANTLR start "T__64"
    public final void mT__64() throws RecognitionException {
        try {
            int _type = T__64;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:22:7: ( '*' )
            // parser/Grammerats.g:22:9: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__64"

    // $ANTLR start "T__65"
    public final void mT__65() throws RecognitionException {
        try {
            int _type = T__65;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:23:7: ( '-' )
            // parser/Grammerats.g:23:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__65"

    // $ANTLR start "T__66"
    public final void mT__66() throws RecognitionException {
        try {
            int _type = T__66;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:24:7: ( '+' )
            // parser/Grammerats.g:24:9: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__66"

    // $ANTLR start "T__67"
    public final void mT__67() throws RecognitionException {
        try {
            int _type = T__67;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:25:7: ( '<' )
            // parser/Grammerats.g:25:9: '<'
            {
            match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__67"

    // $ANTLR start "T__68"
    public final void mT__68() throws RecognitionException {
        try {
            int _type = T__68;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:26:7: ( '>' )
            // parser/Grammerats.g:26:9: '>'
            {
            match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__68"

    // $ANTLR start "T__69"
    public final void mT__69() throws RecognitionException {
        try {
            int _type = T__69;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:27:7: ( '!=' )
            // parser/Grammerats.g:27:9: '!='
            {
            match("!="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__69"

    // $ANTLR start "T__70"
    public final void mT__70() throws RecognitionException {
        try {
            int _type = T__70;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:28:7: ( '==' )
            // parser/Grammerats.g:28:9: '=='
            {
            match("=="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__70"

    // $ANTLR start "T__71"
    public final void mT__71() throws RecognitionException {
        try {
            int _type = T__71;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:29:7: ( '&&' )
            // parser/Grammerats.g:29:9: '&&'
            {
            match("&&"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__71"

    // $ANTLR start "T__72"
    public final void mT__72() throws RecognitionException {
        try {
            int _type = T__72;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:30:7: ( 'if' )
            // parser/Grammerats.g:30:9: 'if'
            {
            match("if"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__72"

    // $ANTLR start "T__73"
    public final void mT__73() throws RecognitionException {
        try {
            int _type = T__73;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:31:7: ( 'then' )
            // parser/Grammerats.g:31:9: 'then'
            {
            match("then"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__73"

    // $ANTLR start "T__74"
    public final void mT__74() throws RecognitionException {
        try {
            int _type = T__74;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:32:7: ( 'else' )
            // parser/Grammerats.g:32:9: 'else'
            {
            match("else"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__74"

    // $ANTLR start "T__75"
    public final void mT__75() throws RecognitionException {
        try {
            int _type = T__75;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:33:7: ( 'while' )
            // parser/Grammerats.g:33:9: 'while'
            {
            match("while"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__75"

    // $ANTLR start "T__76"
    public final void mT__76() throws RecognitionException {
        try {
            int _type = T__76;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:34:7: ( 'for' )
            // parser/Grammerats.g:34:9: 'for'
            {
            match("for"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__76"

    // $ANTLR start "T__77"
    public final void mT__77() throws RecognitionException {
        try {
            int _type = T__77;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:35:7: ( 'return' )
            // parser/Grammerats.g:35:9: 'return'
            {
            match("return"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__77"

    // $ANTLR start "T__78"
    public final void mT__78() throws RecognitionException {
        try {
            int _type = T__78;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:36:7: ( 'void' )
            // parser/Grammerats.g:36:9: 'void'
            {
            match("void"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__78"

    // $ANTLR start "T__79"
    public final void mT__79() throws RecognitionException {
        try {
            int _type = T__79;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:37:7: ( 'int' )
            // parser/Grammerats.g:37:9: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__79"

    // $ANTLR start "T__80"
    public final void mT__80() throws RecognitionException {
        try {
            int _type = T__80;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:38:7: ( 'char' )
            // parser/Grammerats.g:38:9: 'char'
            {
            match("char"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__80"

    // $ANTLR start "T__81"
    public final void mT__81() throws RecognitionException {
        try {
            int _type = T__81;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:39:7: ( 'float' )
            // parser/Grammerats.g:39:9: 'float'
            {
            match("float"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__81"

    // $ANTLR start "T__82"
    public final void mT__82() throws RecognitionException {
        try {
            int _type = T__82;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:40:7: ( 'double' )
            // parser/Grammerats.g:40:9: 'double'
            {
            match("double"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__82"

    // $ANTLR start "INT"
    public final void mINT() throws RecognitionException {
        try {
            int _type = INT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:132:5: ( ( '0' .. '9' )+ )
            // parser/Grammerats.g:132:7: ( '0' .. '9' )+
            {
            // parser/Grammerats.g:132:7: ( '0' .. '9' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // parser/Grammerats.g:132:8: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT"

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            int _type = ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:133:4: ( ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '_' )+ )
            // parser/Grammerats.g:133:6: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '_' )+
            {
            // parser/Grammerats.g:133:6: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '_' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')||(LA2_0>='A' && LA2_0<='Z')||LA2_0=='_'||(LA2_0>='a' && LA2_0<='z')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // parser/Grammerats.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // parser/Grammerats.g:134:4: ( ( ' ' | '\\t' | ( '\\r\\n' | '\\n' | '\\r' ) ) )
            // parser/Grammerats.g:134:6: ( ' ' | '\\t' | ( '\\r\\n' | '\\n' | '\\r' ) )
            {
            // parser/Grammerats.g:134:6: ( ' ' | '\\t' | ( '\\r\\n' | '\\n' | '\\r' ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case ' ':
                {
                alt4=1;
                }
                break;
            case '\t':
                {
                alt4=2;
                }
                break;
            case '\n':
            case '\r':
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // parser/Grammerats.g:134:7: ' '
                    {
                    match(' '); 

                    }
                    break;
                case 2 :
                    // parser/Grammerats.g:134:13: '\\t'
                    {
                    match('\t'); 

                    }
                    break;
                case 3 :
                    // parser/Grammerats.g:134:20: ( '\\r\\n' | '\\n' | '\\r' )
                    {
                    // parser/Grammerats.g:134:20: ( '\\r\\n' | '\\n' | '\\r' )
                    int alt3=3;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0=='\r') ) {
                        int LA3_1 = input.LA(2);

                        if ( (LA3_1=='\n') ) {
                            alt3=1;
                        }
                        else {
                            alt3=3;}
                    }
                    else if ( (LA3_0=='\n') ) {
                        alt3=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 3, 0, input);

                        throw nvae;
                    }
                    switch (alt3) {
                        case 1 :
                            // parser/Grammerats.g:134:22: '\\r\\n'
                            {
                            match("\r\n"); 


                            }
                            break;
                        case 2 :
                            // parser/Grammerats.g:134:31: '\\n'
                            {
                            match('\n'); 

                            }
                            break;
                        case 3 :
                            // parser/Grammerats.g:134:38: '\\r'
                            {
                            match('\r'); 

                            }
                            break;

                    }


                    }
                    break;

            }

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    public void mTokens() throws RecognitionException {
        // parser/Grammerats.g:1:8: ( T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | INT | ID | WS )
        int alt5=33;
        alt5 = dfa5.predict(input);
        switch (alt5) {
            case 1 :
                // parser/Grammerats.g:1:10: T__53
                {
                mT__53(); 

                }
                break;
            case 2 :
                // parser/Grammerats.g:1:16: T__54
                {
                mT__54(); 

                }
                break;
            case 3 :
                // parser/Grammerats.g:1:22: T__55
                {
                mT__55(); 

                }
                break;
            case 4 :
                // parser/Grammerats.g:1:28: T__56
                {
                mT__56(); 

                }
                break;
            case 5 :
                // parser/Grammerats.g:1:34: T__57
                {
                mT__57(); 

                }
                break;
            case 6 :
                // parser/Grammerats.g:1:40: T__58
                {
                mT__58(); 

                }
                break;
            case 7 :
                // parser/Grammerats.g:1:46: T__59
                {
                mT__59(); 

                }
                break;
            case 8 :
                // parser/Grammerats.g:1:52: T__60
                {
                mT__60(); 

                }
                break;
            case 9 :
                // parser/Grammerats.g:1:58: T__61
                {
                mT__61(); 

                }
                break;
            case 10 :
                // parser/Grammerats.g:1:64: T__62
                {
                mT__62(); 

                }
                break;
            case 11 :
                // parser/Grammerats.g:1:70: T__63
                {
                mT__63(); 

                }
                break;
            case 12 :
                // parser/Grammerats.g:1:76: T__64
                {
                mT__64(); 

                }
                break;
            case 13 :
                // parser/Grammerats.g:1:82: T__65
                {
                mT__65(); 

                }
                break;
            case 14 :
                // parser/Grammerats.g:1:88: T__66
                {
                mT__66(); 

                }
                break;
            case 15 :
                // parser/Grammerats.g:1:94: T__67
                {
                mT__67(); 

                }
                break;
            case 16 :
                // parser/Grammerats.g:1:100: T__68
                {
                mT__68(); 

                }
                break;
            case 17 :
                // parser/Grammerats.g:1:106: T__69
                {
                mT__69(); 

                }
                break;
            case 18 :
                // parser/Grammerats.g:1:112: T__70
                {
                mT__70(); 

                }
                break;
            case 19 :
                // parser/Grammerats.g:1:118: T__71
                {
                mT__71(); 

                }
                break;
            case 20 :
                // parser/Grammerats.g:1:124: T__72
                {
                mT__72(); 

                }
                break;
            case 21 :
                // parser/Grammerats.g:1:130: T__73
                {
                mT__73(); 

                }
                break;
            case 22 :
                // parser/Grammerats.g:1:136: T__74
                {
                mT__74(); 

                }
                break;
            case 23 :
                // parser/Grammerats.g:1:142: T__75
                {
                mT__75(); 

                }
                break;
            case 24 :
                // parser/Grammerats.g:1:148: T__76
                {
                mT__76(); 

                }
                break;
            case 25 :
                // parser/Grammerats.g:1:154: T__77
                {
                mT__77(); 

                }
                break;
            case 26 :
                // parser/Grammerats.g:1:160: T__78
                {
                mT__78(); 

                }
                break;
            case 27 :
                // parser/Grammerats.g:1:166: T__79
                {
                mT__79(); 

                }
                break;
            case 28 :
                // parser/Grammerats.g:1:172: T__80
                {
                mT__80(); 

                }
                break;
            case 29 :
                // parser/Grammerats.g:1:178: T__81
                {
                mT__81(); 

                }
                break;
            case 30 :
                // parser/Grammerats.g:1:184: T__82
                {
                mT__82(); 

                }
                break;
            case 31 :
                // parser/Grammerats.g:1:190: INT
                {
                mINT(); 

                }
                break;
            case 32 :
                // parser/Grammerats.g:1:194: ID
                {
                mID(); 

                }
                break;
            case 33 :
                // parser/Grammerats.g:1:197: WS
                {
                mWS(); 

                }
                break;

        }

    }


    protected DFA5 dfa5 = new DFA5(this);
    static final String DFA5_eotS =
        "\1\uffff\2\35\4\uffff\1\42\13\uffff\11\35\1\56\2\uffff\2\35\2\uffff"+
        "\1\61\12\35\1\uffff\2\35\1\uffff\1\76\3\35\1\102\7\35\1\uffff\1"+
        "\112\1\113\1\35\1\uffff\2\35\1\117\1\120\3\35\2\uffff\1\124\1\125"+
        "\1\35\2\uffff\3\35\2\uffff\1\132\1\133\1\134\1\135\4\uffff";
    static final String DFA5_eofS =
        "\136\uffff";
    static final String DFA5_minS =
        "\1\11\2\162\4\uffff\1\75\13\uffff\1\146\1\150\1\154\1\150\1\154"+
        "\1\145\1\157\1\150\1\157\1\60\2\uffff\2\157\2\uffff\1\60\1\164\1"+
        "\145\1\163\1\151\1\162\1\157\1\164\1\151\1\141\1\165\1\uffff\2\147"+
        "\1\uffff\1\60\1\156\1\145\1\154\1\60\1\141\1\165\1\144\1\162\1\142"+
        "\2\162\1\uffff\2\60\1\145\1\uffff\1\164\1\162\2\60\1\154\2\141\2"+
        "\uffff\2\60\1\156\2\uffff\1\145\2\155\2\uffff\4\60\4\uffff";
    static final String DFA5_maxS =
        "\1\175\2\162\4\uffff\1\75\13\uffff\1\156\1\150\1\154\1\150\1\157"+
        "\1\145\1\157\1\150\1\157\1\172\2\uffff\2\157\2\uffff\1\172\1\164"+
        "\1\145\1\163\1\151\1\162\1\157\1\164\1\151\1\141\1\165\1\uffff\2"+
        "\147\1\uffff\1\172\1\156\1\145\1\154\1\172\1\141\1\165\1\144\1\162"+
        "\1\142\2\162\1\uffff\2\172\1\145\1\uffff\1\164\1\162\2\172\1\154"+
        "\2\141\2\uffff\2\172\1\156\2\uffff\1\145\2\155\2\uffff\4\172\4\uffff";
    static final String DFA5_acceptS =
        "\3\uffff\1\3\1\4\1\5\1\6\1\uffff\1\10\1\11\1\12\1\13\1\14\1\15\1"+
        "\16\1\17\1\20\1\21\1\23\12\uffff\1\40\1\41\2\uffff\1\22\1\7\13\uffff"+
        "\1\37\2\uffff\1\24\14\uffff\1\33\3\uffff\1\30\7\uffff\1\25\1\26"+
        "\3\uffff\1\32\1\34\3\uffff\1\27\1\35\4\uffff\1\31\1\36\1\1\1\2";
    static final String DFA5_specialS =
        "\136\uffff}>";
    static final String[] DFA5_transitionS = {
            "\2\36\2\uffff\1\36\22\uffff\1\36\1\21\4\uffff\1\22\1\uffff\1"+
            "\11\1\12\1\14\1\16\1\6\1\15\1\uffff\1\13\12\34\1\uffff\1\5\1"+
            "\17\1\7\1\20\2\uffff\17\35\1\1\12\35\4\uffff\1\35\1\uffff\2"+
            "\35\1\32\1\33\1\25\1\27\2\35\1\23\6\35\1\2\1\35\1\30\1\35\1"+
            "\24\1\35\1\31\1\26\3\35\1\3\1\10\1\4",
            "\1\37",
            "\1\40",
            "",
            "",
            "",
            "",
            "\1\41",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\43\7\uffff\1\44",
            "\1\45",
            "\1\46",
            "\1\47",
            "\1\51\2\uffff\1\50",
            "\1\52",
            "\1\53",
            "\1\54",
            "\1\55",
            "\12\34\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "",
            "",
            "\1\57",
            "\1\60",
            "",
            "",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\62",
            "\1\63",
            "\1\64",
            "\1\65",
            "\1\66",
            "\1\67",
            "\1\70",
            "\1\71",
            "\1\72",
            "\1\73",
            "",
            "\1\74",
            "\1\75",
            "",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\77",
            "\1\100",
            "\1\101",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\103",
            "\1\104",
            "\1\105",
            "\1\106",
            "\1\107",
            "\1\110",
            "\1\111",
            "",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\114",
            "",
            "\1\115",
            "\1\116",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\121",
            "\1\122",
            "\1\123",
            "",
            "",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\1\126",
            "",
            "",
            "\1\127",
            "\1\130",
            "\1\131",
            "",
            "",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "\12\35\7\uffff\32\35\4\uffff\1\35\1\uffff\32\35",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA5_eot = DFA.unpackEncodedString(DFA5_eotS);
    static final short[] DFA5_eof = DFA.unpackEncodedString(DFA5_eofS);
    static final char[] DFA5_min = DFA.unpackEncodedStringToUnsignedChars(DFA5_minS);
    static final char[] DFA5_max = DFA.unpackEncodedStringToUnsignedChars(DFA5_maxS);
    static final short[] DFA5_accept = DFA.unpackEncodedString(DFA5_acceptS);
    static final short[] DFA5_special = DFA.unpackEncodedString(DFA5_specialS);
    static final short[][] DFA5_transition;

    static {
        int numStates = DFA5_transitionS.length;
        DFA5_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA5_transition[i] = DFA.unpackEncodedString(DFA5_transitionS[i]);
        }
    }

    class DFA5 extends DFA {

        public DFA5(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 5;
            this.eot = DFA5_eot;
            this.eof = DFA5_eof;
            this.min = DFA5_min;
            this.max = DFA5_max;
            this.accept = DFA5_accept;
            this.special = DFA5_special;
            this.transition = DFA5_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__53 | T__54 | T__55 | T__56 | T__57 | T__58 | T__59 | T__60 | T__61 | T__62 | T__63 | T__64 | T__65 | T__66 | T__67 | T__68 | T__69 | T__70 | T__71 | T__72 | T__73 | T__74 | T__75 | T__76 | T__77 | T__78 | T__79 | T__80 | T__81 | T__82 | INT | ID | WS );";
        }
    }
 

}