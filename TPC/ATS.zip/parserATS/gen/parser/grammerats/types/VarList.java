
package parser.grammerats.types;


public abstract class VarList extends parser.grammerats.GrammeratsAbstractType  {
  /**
   * Sole constructor.  (For invocation by subclass
   * constructors, typically implicit.)
   */
  protected VarList() {}



  /**
   * Returns true if the term is rooted by the symbol ConsVarList
   *
   * @return true if the term is rooted by the symbol ConsVarList
   */
  public boolean isConsVarList() {
    return false;
  }

  /**
   * Returns true if the term is rooted by the symbol EmptyVarList
   *
   * @return true if the term is rooted by the symbol EmptyVarList
   */
  public boolean isEmptyVarList() {
    return false;
  }

  /**
   * Returns the subterm corresponding to the slot HeadVarList
   *
   * @return the subterm corresponding to the slot HeadVarList
   */
  public parser.grammerats.types.Id getHeadVarList() {
    throw new UnsupportedOperationException("This VarList has no HeadVarList");
  }

  /**
   * Returns a new term where the subterm corresponding to the slot HeadVarList
   * is replaced by the term given in argument.
   * Note that there is no side-effect: a new term is returned and the original term is left unchanged
   *
   * @param _arg the value of the new subterm
   * @return a new term where the subterm corresponding to the slot HeadVarList is replaced by _arg
   */
  public VarList setHeadVarList(parser.grammerats.types.Id _arg) {
    throw new UnsupportedOperationException("This VarList has no HeadVarList");
  }

  /**
   * Returns the subterm corresponding to the slot TailVarList
   *
   * @return the subterm corresponding to the slot TailVarList
   */
  public parser.grammerats.types.VarList getTailVarList() {
    throw new UnsupportedOperationException("This VarList has no TailVarList");
  }

  /**
   * Returns a new term where the subterm corresponding to the slot TailVarList
   * is replaced by the term given in argument.
   * Note that there is no side-effect: a new term is returned and the original term is left unchanged
   *
   * @param _arg the value of the new subterm
   * @return a new term where the subterm corresponding to the slot TailVarList is replaced by _arg
   */
  public VarList setTailVarList(parser.grammerats.types.VarList _arg) {
    throw new UnsupportedOperationException("This VarList has no TailVarList");
  }

  protected static tom.library.utils.IdConverter idConv = new tom.library.utils.IdConverter();

  /**
   * Returns an ATerm representation of this term.
   *
   * @return null to indicate to sub-classes that they have to work
   */
  public aterm.ATerm toATerm() {
    // returns null to indicate sub-classes that they have to work
    return null;
  }

  /**
   * Returns a parser.grammerats.types.VarList from an ATerm without any conversion
   *
   * @param trm ATerm to handle to retrieve a Gom term
   * @return the term from the ATerm
   */
  public static parser.grammerats.types.VarList fromTerm(aterm.ATerm trm) {
    return fromTerm(trm,idConv);
  }

  /**
   * Returns a parser.grammerats.types.VarList from a String without any conversion
   *
   * @param s String containing the ATerm
   * @return the term from the String
   */
  public static parser.grammerats.types.VarList fromString(String s) {
    return fromTerm(atermFactory.parse(s),idConv);
  }

  /**
   * Returns a parser.grammerats.types.VarList from a Stream without any conversion
   *
   * @param stream stream containing the ATerm
   * @return the term from the Stream
   * @throws java.io.IOException if a problem occurs with the stream
   */
  public static parser.grammerats.types.VarList fromStream(java.io.InputStream stream) throws java.io.IOException {
    return fromTerm(atermFactory.readFromFile(stream),idConv);
  }

  /**
   * Apply a conversion on the ATerm and returns a parser.grammerats.types.VarList
   *
   * @param trm ATerm to convert into a Gom term
   * @param atConv ATermConverter used to convert the ATerm
   * @return the Gom term
   * @throws IllegalArgumentException
   */
  public static parser.grammerats.types.VarList fromTerm(aterm.ATerm trm, tom.library.utils.ATermConverter atConv) {
    aterm.ATerm convertedTerm = atConv.convert(trm);
    parser.grammerats.types.VarList tmp;
    java.util.ArrayList<parser.grammerats.types.VarList> results = new java.util.ArrayList<parser.grammerats.types.VarList>();

    tmp = parser.grammerats.types.varlist.ConsVarList.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.varlist.EmptyVarList.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.varlist.VarList.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    switch(results.size()) {
      case 0:
        throw new IllegalArgumentException(trm + " is not a VarList");
      case 1:
        return results.get(0);
      default:
        java.util.logging.Logger.getLogger("VarList").log(java.util.logging.Level.WARNING,"There were many possibilities ({0}) in {1} but the first one was chosen: {2}",new Object[] {results.toString(), "parser.grammerats.types.VarList", results.get(0).toString()});
        return results.get(0);
    }
  }

  /**
   * Apply a conversion on the ATerm contained in the String and returns a parser.grammerats.types.VarList from it
   *
   * @param s String containing the ATerm
   * @param atConv ATerm Converter used to convert the ATerm
   * @return the Gom term
   */
  public static parser.grammerats.types.VarList fromString(String s, tom.library.utils.ATermConverter atConv) {
    return fromTerm(atermFactory.parse(s),atConv);
  }

  /**
   * Apply a conversion on the ATerm contained in the Stream and returns a parser.grammerats.types.VarList from it
   *
   * @param stream stream containing the ATerm
   * @param atConv ATerm Converter used to convert the ATerm
   * @return the Gom term
   */
  public static parser.grammerats.types.VarList fromStream(java.io.InputStream stream, tom.library.utils.ATermConverter atConv) throws java.io.IOException {
    return fromTerm(atermFactory.readFromFile(stream),atConv);
  }

  /**
   * Returns the length of the list
   *
   * @return the length of the list
   * @throws IllegalArgumentException if the term is not a list
   */
  public int length() {
    throw new IllegalArgumentException(
      "This "+this.getClass().getName()+" is not a list");
  }

  /**
   * Returns an inverted term
   *
   * @return the inverted list
   * @throws IllegalArgumentException if the term is not a list
   */
  public parser.grammerats.types.VarList reverse() {
    throw new IllegalArgumentException(
      "This "+this.getClass().getName()+" is not a list");
  }
  
  /**
   * Returns a Collection extracted from the term
   *
   * @return the collection
   * @throws UnsupportedOperationException if the term is not a list
   */
  public java.util.Collection<parser.grammerats.types.Id> getCollectionVarList() {
    throw new UnsupportedOperationException("This VarList cannot be converted into a Collection");
  }
          
}
