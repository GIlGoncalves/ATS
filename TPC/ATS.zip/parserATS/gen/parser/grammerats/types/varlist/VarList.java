
package parser.grammerats.types.varlist;



public abstract class VarList extends parser.grammerats.types.VarList implements java.util.Collection<parser.grammerats.types.Id>  {


  /**
   * Returns the number of arguments of the variadic operator
   *
   * @return the number of arguments of the variadic operator
   */
  @Override
  public int length() {
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList tl = this.getTailVarList();
      if (tl instanceof VarList) {
        return 1+((VarList)tl).length();
      } else {
        return 2;
      }
    } else {
      return 0;
    }
  }

  public static parser.grammerats.types.VarList fromArray(parser.grammerats.types.Id[] array) {
    parser.grammerats.types.VarList res = parser.grammerats.types.varlist.EmptyVarList.make();
    for(int i = array.length; i>0;) {
      res = parser.grammerats.types.varlist.ConsVarList.make(array[--i],res);
    }
    return res;
  }

  /**
   * Inverses the term if it is a list
   *
   * @return the inverted term if it is a list, otherwise the term itself
   */
  @Override
  public parser.grammerats.types.VarList reverse() {
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList cur = this;
      parser.grammerats.types.VarList rev = parser.grammerats.types.varlist.EmptyVarList.make();
      while(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
        rev = parser.grammerats.types.varlist.ConsVarList.make(cur.getHeadVarList(),rev);
        cur = cur.getTailVarList();
      }

      return rev;
    } else {
      return this;
    }
  }

  /**
   * Appends an element
   *
   * @param element element which has to be added
   * @return the term with the added element
   */
  public parser.grammerats.types.VarList append(parser.grammerats.types.Id element) {
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList tl = this.getTailVarList();
      if (tl instanceof VarList) {
        return parser.grammerats.types.varlist.ConsVarList.make(this.getHeadVarList(),((VarList)tl).append(element));
      } else {

        return parser.grammerats.types.varlist.ConsVarList.make(this.getHeadVarList(),parser.grammerats.types.varlist.ConsVarList.make(element,tl));

      }
    } else {
      return parser.grammerats.types.varlist.ConsVarList.make(element,this);
    }
  }

  /**
   * Appends a string representation of this term to the buffer given as argument.
   *
   * @param buffer the buffer to which a string represention of this term is appended.
   */
  @Override
  public void toStringBuilder(java.lang.StringBuilder buffer) {
    buffer.append("VarList(");
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList cur = this;
      while(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
        parser.grammerats.types.Id elem = cur.getHeadVarList();
        cur = cur.getTailVarList();
        elem.toStringBuilder(buffer);

        if(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
          buffer.append(",");
        }
      }
      if(!(cur instanceof parser.grammerats.types.varlist.EmptyVarList)) {
        buffer.append(",");
        cur.toStringBuilder(buffer);
      }
    }
    buffer.append(")");
  }

  /**
   * Returns an ATerm representation of this term.
   *
   * @return an ATerm representation of this term.
   */
  public aterm.ATerm toATerm() {
    aterm.ATerm res = atermFactory.makeList();
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList tail = this.getTailVarList();
      res = atermFactory.makeList(getHeadVarList().toATerm(),(aterm.ATermList)tail.toATerm());
    }
    return res;
  }

  /**
   * Apply a conversion on the ATerm contained in the String and returns a parser.grammerats.types.VarList from it
   *
   * @param trm ATerm to convert into a Gom term
   * @param atConv ATerm Converter used to convert the ATerm
   * @return the Gom term
   */
  public static parser.grammerats.types.VarList fromTerm(aterm.ATerm trm, tom.library.utils.ATermConverter atConv) {
    trm = atConv.convert(trm);
    if(trm instanceof aterm.ATermAppl) {
      aterm.ATermAppl appl = (aterm.ATermAppl) trm;
      if("VarList".equals(appl.getName())) {
        parser.grammerats.types.VarList res = parser.grammerats.types.varlist.EmptyVarList.make();

        aterm.ATerm array[] = appl.getArgumentArray();
        for(int i = array.length-1; i>=0; --i) {
          parser.grammerats.types.Id elem = parser.grammerats.types.Id.fromTerm(array[i],atConv);
          res = parser.grammerats.types.varlist.ConsVarList.make(elem,res);
        }
        return res;
      }
    }

    if(trm instanceof aterm.ATermList) {
      aterm.ATermList list = (aterm.ATermList) trm;
      parser.grammerats.types.VarList res = parser.grammerats.types.varlist.EmptyVarList.make();
      try {
        while(!list.isEmpty()) {
          parser.grammerats.types.Id elem = parser.grammerats.types.Id.fromTerm(list.getFirst(),atConv);
          res = parser.grammerats.types.varlist.ConsVarList.make(elem,res);
          list = list.getNext();
        }
      } catch(IllegalArgumentException e) {
        // returns null when the fromATerm call failed
        return null;
      }
      return res.reverse();
    }

    return null;
  }

  /*
   * Checks if the Collection contains all elements of the parameter Collection
   *
   * @param c the Collection of elements to check
   * @return true if the Collection contains all elements of the parameter, otherwise false
   */
  public boolean containsAll(java.util.Collection c) {
    java.util.Iterator it = c.iterator();
    while(it.hasNext()) {
      if(!this.contains(it.next())) {
        return false;
      }
    }
    return true;
  }

  /**
   * Checks if parser.grammerats.types.VarList contains a specified object
   *
   * @param o object whose presence is tested
   * @return true if parser.grammerats.types.VarList contains the object, otherwise false
   */
  public boolean contains(Object o) {
    parser.grammerats.types.VarList cur = this;
    if(o==null) { return false; }
    if(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
      while(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
        if( o.equals(cur.getHeadVarList()) ) {
          return true;
        }
        cur = cur.getTailVarList();
      }
      if(!(cur instanceof parser.grammerats.types.varlist.EmptyVarList)) {
        if( o.equals(cur) ) {
          return true;
        }
      }
    }
    return false;
  }

  //public boolean equals(Object o) { return this == o; }

  //public int hashCode() { return hashCode(); }

  /**
   * Checks the emptiness
   *
   * @return true if empty, otherwise false
   */
  public boolean isEmpty() { return isEmptyVarList() ; }

  public java.util.Iterator<parser.grammerats.types.Id> iterator() {
    return new java.util.Iterator<parser.grammerats.types.Id>() {
      parser.grammerats.types.VarList list = VarList.this;

      public boolean hasNext() {
        return list!=null && !list.isEmptyVarList();
      }

      public parser.grammerats.types.Id next() {
        if(list.isEmptyVarList()) {
          throw new java.util.NoSuchElementException();
        }
        if(list.isConsVarList()) {
          parser.grammerats.types.Id head = list.getHeadVarList();
          list = list.getTailVarList();
          return head;
        } else {
          // we are in this case only if domain=codomain
          // thus, the cast is safe
          Object res = list;
          list = null;
          return (parser.grammerats.types.Id)res;
        }
      }

      public void remove() {
        throw new UnsupportedOperationException("Not yet implemented");
      }
    };

  }

  public boolean add(parser.grammerats.types.Id o) {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  public boolean addAll(java.util.Collection<? extends parser.grammerats.types.Id> c) {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  public boolean remove(Object o) {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  public void clear() {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  public boolean removeAll(java.util.Collection c) {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  public boolean retainAll(java.util.Collection c) {
    throw new UnsupportedOperationException("This object "+this.getClass().getName()+" is not mutable");
  }

  /**
   * Returns the size of the collection
   *
   * @return the size of the collection
   */
  public int size() { return length(); }

  /**
   * Returns an array containing the elements of the collection
   *
   * @return an array of elements
   */
  public Object[] toArray() {
    int size = this.length();
    Object[] array = new Object[size];
    int i=0;
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList cur = this;
      while(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
        parser.grammerats.types.Id elem = cur.getHeadVarList();
        array[i] = elem;
        cur = cur.getTailVarList();
        i++;
      }
      if(!(cur instanceof parser.grammerats.types.varlist.EmptyVarList)) {
        array[i] = cur;
      }
    }
    return array;
  }

  @SuppressWarnings("unchecked")
  public <T> T[] toArray(T[] array) {
    int size = this.length();
    if (array.length < size) {
      array = (T[]) java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), size);
    } else if (array.length > size) {
      array[size] = null;
    }
    int i=0;
    if(this instanceof parser.grammerats.types.varlist.ConsVarList) {
      parser.grammerats.types.VarList cur = this;
      while(cur instanceof parser.grammerats.types.varlist.ConsVarList) {
        parser.grammerats.types.Id elem = cur.getHeadVarList();
        array[i] = (T)elem;
        cur = cur.getTailVarList();
        i++;
      }
      if(!(cur instanceof parser.grammerats.types.varlist.EmptyVarList)) {
        array[i] = (T)cur;
      }
    }
    return array;
  }

  /*
   * to get a Collection for an immutable list
   */
  public java.util.Collection<parser.grammerats.types.Id> getCollection() {
    return new CollectionVarList(this);
  }

  public java.util.Collection<parser.grammerats.types.Id> getCollectionVarList() {
    return new CollectionVarList(this);
  }

  /************************************************************
   * private static class
   ************************************************************/
  private static class CollectionVarList implements java.util.Collection<parser.grammerats.types.Id> {
    private VarList list;

    public VarList getVarList() {
      return list;
    }

    public CollectionVarList(VarList list) {
      this.list = list;
    }

    /**
     * generic
     */
  public boolean addAll(java.util.Collection<? extends parser.grammerats.types.Id> c) {
    boolean modified = false;
    java.util.Iterator<? extends parser.grammerats.types.Id> it = c.iterator();
    while(it.hasNext()) {
      modified = modified || add(it.next());
    }
    return modified;
  }

  /**
   * Checks if the collection contains an element
   *
   * @param o element whose presence has to be checked
   * @return true if the element is found, otherwise false
   */
  public boolean contains(Object o) {
    return getVarList().contains(o);
  }

  /**
   * Checks if the collection contains elements given as parameter
   *
   * @param c elements whose presence has to be checked
   * @return true all the elements are found, otherwise false
   */
  public boolean containsAll(java.util.Collection<?> c) {
    return getVarList().containsAll(c);
  }

  /**
   * Checks if an object is equal
   *
   * @param o object which is compared
   * @return true if objects are equal, false otherwise
   */
  @Override
  public boolean equals(Object o) {
    return getVarList().equals(o);
  }

  /**
   * Returns the hashCode
   *
   * @return the hashCode
   */
  @Override
  public int hashCode() {
    return getVarList().hashCode();
  }

  /**
   * Returns an iterator over the elements in the collection
   *
   * @return an iterator over the elements in the collection
   */
  public java.util.Iterator<parser.grammerats.types.Id> iterator() {
    return getVarList().iterator();
  }

  /**
   * Return the size of the collection
   *
   * @return the size of the collection
   */
  public int size() {
    return getVarList().size();
  }

  /**
   * Returns an array containing all of the elements in this collection.
   *
   * @return an array of elements
   */
  public Object[] toArray() {
    return getVarList().toArray();
  }

  /**
   * Returns an array containing all of the elements in this collection.
   *
   * @param array array which will contain the result
   * @return an array of elements
   */
  public <T> T[] toArray(T[] array) {
    return getVarList().toArray(array);
  }

/*
  public <T> T[] toArray(T[] array) {
    int size = getVarList().length();
    if (array.length < size) {
      array = (T[]) java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), size);
    } else if (array.length > size) {
      array[size] = null;
    }
    int i=0;
    for(java.util.Iterator it=iterator() ; it.hasNext() ; i++) {
        array[i] = (T)it.next();
    }
    return array;
  }
*/
    /**
     * Collection
     */

    /**
     * Adds an element to the collection
     *
     * @param o element to add to the collection
     * @return true if it is a success
     */
    public boolean add(parser.grammerats.types.Id o) {
      list = (VarList)parser.grammerats.types.varlist.ConsVarList.make(o,list);
      return true;
    }

    /**
     * Removes all of the elements from this collection
     */
    public void clear() {
      list = (VarList)parser.grammerats.types.varlist.EmptyVarList.make();
    }

    /**
     * Tests the emptiness of the collection
     *
     * @return true if the collection is empty
     */
    public boolean isEmpty() {
      return list.isEmptyVarList();
    }

    public boolean remove(Object o) {
      throw new UnsupportedOperationException("Not yet implemented");
    }

    public boolean removeAll(java.util.Collection<?> c) {
      throw new UnsupportedOperationException("Not yet implemented");
    }

    public boolean retainAll(java.util.Collection<?> c) {
      throw new UnsupportedOperationException("Not yet implemented");
    }

  }


}
