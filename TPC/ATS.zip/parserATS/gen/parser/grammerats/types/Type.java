
package parser.grammerats.types;


public abstract class Type extends parser.grammerats.GrammeratsAbstractType  {
  /**
   * Sole constructor.  (For invocation by subclass
   * constructors, typically implicit.)
   */
  protected Type() {}



  /**
   * Returns true if the term is rooted by the symbol TypeVoid
   *
   * @return true if the term is rooted by the symbol TypeVoid
   */
  public boolean isTypeVoid() {
    return false;
  }

  /**
   * Returns true if the term is rooted by the symbol TypeInt
   *
   * @return true if the term is rooted by the symbol TypeInt
   */
  public boolean isTypeInt() {
    return false;
  }

  /**
   * Returns true if the term is rooted by the symbol TypeChar
   *
   * @return true if the term is rooted by the symbol TypeChar
   */
  public boolean isTypeChar() {
    return false;
  }

  /**
   * Returns true if the term is rooted by the symbol TypeFloat
   *
   * @return true if the term is rooted by the symbol TypeFloat
   */
  public boolean isTypeFloat() {
    return false;
  }

  /**
   * Returns true if the term is rooted by the symbol TypeDouble
   *
   * @return true if the term is rooted by the symbol TypeDouble
   */
  public boolean isTypeDouble() {
    return false;
  }

  protected static tom.library.utils.IdConverter idConv = new tom.library.utils.IdConverter();

  /**
   * Returns an ATerm representation of this term.
   *
   * @return null to indicate to sub-classes that they have to work
   */
  public aterm.ATerm toATerm() {
    // returns null to indicate sub-classes that they have to work
    return null;
  }

  /**
   * Returns a parser.grammerats.types.Type from an ATerm without any conversion
   *
   * @param trm ATerm to handle to retrieve a Gom term
   * @return the term from the ATerm
   */
  public static parser.grammerats.types.Type fromTerm(aterm.ATerm trm) {
    return fromTerm(trm,idConv);
  }

  /**
   * Returns a parser.grammerats.types.Type from a String without any conversion
   *
   * @param s String containing the ATerm
   * @return the term from the String
   */
  public static parser.grammerats.types.Type fromString(String s) {
    return fromTerm(atermFactory.parse(s),idConv);
  }

  /**
   * Returns a parser.grammerats.types.Type from a Stream without any conversion
   *
   * @param stream stream containing the ATerm
   * @return the term from the Stream
   * @throws java.io.IOException if a problem occurs with the stream
   */
  public static parser.grammerats.types.Type fromStream(java.io.InputStream stream) throws java.io.IOException {
    return fromTerm(atermFactory.readFromFile(stream),idConv);
  }

  /**
   * Apply a conversion on the ATerm and returns a parser.grammerats.types.Type
   *
   * @param trm ATerm to convert into a Gom term
   * @param atConv ATermConverter used to convert the ATerm
   * @return the Gom term
   * @throws IllegalArgumentException
   */
  public static parser.grammerats.types.Type fromTerm(aterm.ATerm trm, tom.library.utils.ATermConverter atConv) {
    aterm.ATerm convertedTerm = atConv.convert(trm);
    parser.grammerats.types.Type tmp;
    java.util.ArrayList<parser.grammerats.types.Type> results = new java.util.ArrayList<parser.grammerats.types.Type>();

    tmp = parser.grammerats.types.type.TypeVoid.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.type.TypeInt.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.type.TypeChar.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.type.TypeFloat.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    tmp = parser.grammerats.types.type.TypeDouble.fromTerm(convertedTerm,atConv);
    if(tmp!=null) {
      results.add(tmp);
    }
    switch(results.size()) {
      case 0:
        throw new IllegalArgumentException(trm + " is not a Type");
      case 1:
        return results.get(0);
      default:
        java.util.logging.Logger.getLogger("Type").log(java.util.logging.Level.WARNING,"There were many possibilities ({0}) in {1} but the first one was chosen: {2}",new Object[] {results.toString(), "parser.grammerats.types.Type", results.get(0).toString()});
        return results.get(0);
    }
  }

  /**
   * Apply a conversion on the ATerm contained in the String and returns a parser.grammerats.types.Type from it
   *
   * @param s String containing the ATerm
   * @param atConv ATerm Converter used to convert the ATerm
   * @return the Gom term
   */
  public static parser.grammerats.types.Type fromString(String s, tom.library.utils.ATermConverter atConv) {
    return fromTerm(atermFactory.parse(s),atConv);
  }

  /**
   * Apply a conversion on the ATerm contained in the Stream and returns a parser.grammerats.types.Type from it
   *
   * @param stream stream containing the ATerm
   * @param atConv ATerm Converter used to convert the ATerm
   * @return the Gom term
   */
  public static parser.grammerats.types.Type fromStream(java.io.InputStream stream, tom.library.utils.ATermConverter atConv) throws java.io.IOException {
    return fromTerm(atermFactory.readFromFile(stream),atConv);
  }

  /**
   * Returns the length of the list
   *
   * @return the length of the list
   * @throws IllegalArgumentException if the term is not a list
   */
  public int length() {
    throw new IllegalArgumentException(
      "This "+this.getClass().getName()+" is not a list");
  }

  /**
   * Returns an inverted term
   *
   * @return the inverted list
   * @throws IllegalArgumentException if the term is not a list
   */
  public parser.grammerats.types.Type reverse() {
    throw new IllegalArgumentException(
      "This "+this.getClass().getName()+" is not a list");
  }
  
}
