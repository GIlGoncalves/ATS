
package parser.grammerats;

import org.antlr.runtime.Token;
import org.antlr.runtime.tree.Tree;


public class GrammeratsAdaptor {
  public static shared.SharedObject getTerm(Tree tree) {
    shared.SharedObject res = null;
    if (tree.isNil()) {
      throw new RuntimeException("nil term");
    }
    if (tree.getType()==Token.INVALID_TOKEN_TYPE) {
      throw new RuntimeException("bad type");
    }

    switch (tree.getType()) {
      case 49:
        {

          if (tree.getChildCount()!=3) {
            throw new RuntimeException("Node " + tree + ": 3 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Expression field0 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.StmList field1 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(1));
          parser.grammerats.types.StmList field2 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(2));
          res = parser.grammerats.types.selectionstm.IfElse.make(field0, field1, field2);
          break;
        }
      case 10:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.AssignmentStm field0 = (parser.grammerats.types.AssignmentStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.forinit.AtribF.make(field0);
          break;
        }
      case 20:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.And.make();
          break;
        }
      case 32:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.IterationStm field0 = (parser.grammerats.types.IterationStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.stm.StatementIteration.make(field0);
          break;
        }
      case 17:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Bigger.make();
          break;
        }
      case 16:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Less.make();
          break;
        }
      case 28:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          String field0 = tree.getChild(0).getText();
          res = parser.grammerats.types.expression.IdVar.make(field0);
          break;
        }
      case 48:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Expression field0 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.StmList field1 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.selectionstm.IfStatement.make(field0, field1);
          break;
        }
      case 29:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          int field0 = Integer.parseInt(tree.getChild(0).getText());
          res = parser.grammerats.types.expression.Int.make(field0);
          break;
        }
      case 21:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Or.make();
          break;
        }
      case 11:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.ADecl field0 = (parser.grammerats.types.ADecl)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.forinit.InitF.make(field0);
          break;
        }
      case 38:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Type field0 = (parser.grammerats.types.Type)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.VarList field1 = (parser.grammerats.types.VarList)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.sdecl.Declaration.make(field0, field1);
          break;
        }
      case 12:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Div.make();
          break;
        }
      case 22:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Id field0 = (parser.grammerats.types.Id)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.StmList field1 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.nprogram.Program.make(field0, field1);
          break;
        }
      case 27:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          String field0 = tree.getChild(0).getText();
          res = parser.grammerats.types.id.Id.make(field0);
          break;
        }
      case 37:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Expression field0 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.StmList field1 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.iterationstm.WhileStatement.make(field0, field1);
          break;
        }
      case 34:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.AssignmentStm field0 = (parser.grammerats.types.AssignmentStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.stm.StatementAssignment.make(field0);
          break;
        }
      case 25:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Id field0 = (parser.grammerats.types.Id)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.Expression field1 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.assignmentstm.Assignment.make(field0, field1);
          break;
        }
      case 23:
        {
          res = parser.grammerats.types.stmlist.EmptyStmList.make();
          for(int i = 0; i < tree.getChildCount(); i++) {
            parser.grammerats.types.Stm elem = (parser.grammerats.types.Stm)GrammeratsAdaptor.getTerm(tree.getChild(i));
            parser.grammerats.types.stmlist.StmList list = (parser.grammerats.types.stmlist.StmList) res;
            res = list.append(elem);
          }
          break;
        }
      case 35:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.DeclarationStm field0 = (parser.grammerats.types.DeclarationStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.stm.StatementDeclaration.make(field0);
          break;
        }
      case 33:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.SelectionStm field0 = (parser.grammerats.types.SelectionStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.stm.StatementSelection.make(field0);
          break;
        }
      case 43:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.type.TypeVoid.make();
          break;
        }
      case 14:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Minus.make();
          break;
        }
      case 26:
        {
          res = parser.grammerats.types.programs.EmptyListProgram.make();
          for(int i = 0; i < tree.getChildCount(); i++) {
            parser.grammerats.types.NProgram elem = (parser.grammerats.types.NProgram)GrammeratsAdaptor.getTerm(tree.getChild(i));
            parser.grammerats.types.programs.ListProgram list = (parser.grammerats.types.programs.ListProgram) res;
            res = list.append(elem);
          }
          break;
        }
      case 41:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.type.TypeChar.make();
          break;
        }
      case 30:
        {

          if (tree.getChildCount()!=3) {
            throw new RuntimeException("Node " + tree + ": 3 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Expression field0 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.Op field1 = (parser.grammerats.types.Op)GrammeratsAdaptor.getTerm(tree.getChild(1));
          parser.grammerats.types.Expression field2 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(2));
          res = parser.grammerats.types.expression.OpExp.make(field0, field1, field2);
          break;
        }
      case 36:
        {

          if (tree.getChildCount()!=4) {
            throw new RuntimeException("Node " + tree + ": 4 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.ForInit field0 = (parser.grammerats.types.ForInit)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.Expression field1 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(1));
          parser.grammerats.types.AssignmentStm field2 = (parser.grammerats.types.AssignmentStm)GrammeratsAdaptor.getTerm(tree.getChild(2));
          parser.grammerats.types.StmList field3 = (parser.grammerats.types.StmList)GrammeratsAdaptor.getTerm(tree.getChild(3));
          res = parser.grammerats.types.iterationstm.ForStatement.make(field0, field1, field2, field3);
          break;
        }
      case 24:
        {
          res = parser.grammerats.types.varlist.EmptyVarList.make();
          for(int i = 0; i < tree.getChildCount(); i++) {
            parser.grammerats.types.Id elem = (parser.grammerats.types.Id)GrammeratsAdaptor.getTerm(tree.getChild(i));
            parser.grammerats.types.varlist.VarList list = (parser.grammerats.types.varlist.VarList) res;
            res = list.append(elem);
          }
          break;
        }
      case 45:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.SDecl field0 = (parser.grammerats.types.SDecl)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.declarationstm.SimpleDeclaration.make(field0);
          break;
        }
      case 40:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.type.TypeFloat.make();
          break;
        }
      case 39:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.type.TypeDouble.make();
          break;
        }
      case 18:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Diff.make();
          break;
        }
      case 13:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Times.make();
          break;
        }
      case 47:
        {

          if (tree.getChildCount()!=2) {
            throw new RuntimeException("Node " + tree + ": 2 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Type field0 = (parser.grammerats.types.Type)GrammeratsAdaptor.getTerm(tree.getChild(0));
          parser.grammerats.types.AssignmentStm field1 = (parser.grammerats.types.AssignmentStm)GrammeratsAdaptor.getTerm(tree.getChild(1));
          res = parser.grammerats.types.adecl.DeclarationAssignment.make(field0, field1);
          break;
        }
      case 46:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.Expression field0 = (parser.grammerats.types.Expression)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.returnstm.ReturnStatement.make(field0);
          break;
        }
      case 15:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Plus.make();
          break;
        }
      case 19:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.op.Equal.make();
          break;
        }
      case 42:
        {

          if (tree.getChildCount()!=0) {
            throw new RuntimeException("Node " + tree + ": 0 child(s) expected, but " + tree.getChildCount() + " found");
          }
          res = parser.grammerats.types.type.TypeInt.make();
          break;
        }
      case 31:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.ReturnStm field0 = (parser.grammerats.types.ReturnStm)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.stm.StatementReturn.make(field0);
          break;
        }
      case 44:
        {

          if (tree.getChildCount()!=1) {
            throw new RuntimeException("Node " + tree + ": 1 child(s) expected, but " + tree.getChildCount() + " found");
          }
          parser.grammerats.types.ADecl field0 = (parser.grammerats.types.ADecl)GrammeratsAdaptor.getTerm(tree.getChild(0));
          res = parser.grammerats.types.declarationstm.AssignmentDeclaration.make(field0);
          break;
        }

    }
    return res;
  }
}
