package parser; 
 
public class Node {

	public String node;
	public String label;

	public Node(){
		this.node = "";
		this.label = "";
	}

	public Node(String n, String l) {
		this.node = n;
		this.label = l;
	}

	public String toString() {
		return this.node + " [label= \"" + this.label + "\" ];";
	}

	@Override
	public boolean equals(Object other){
    	if (other == null) return false;
    	if (other == this) return true;
    	if (!(other instanceof Node))return false;
    	Node otherMyClass = (Node)other;
    	return this.node.equals(otherMyClass.node) && this.label.equals(otherMyClass.label);
	}
}