package parser; 
 
public class Edge {

	public String nodea;
	public String nodeb;

	public Edge(){
		this.nodea = "";
		this.nodeb = "";
	}

	public Edge(String n1, String n2) {
		this.nodea = n1;
		this.nodeb = n2;
	}

	@Override
	public String toString() {
        return this.nodea + " -> " + this.nodeb +";";	
	}

	@Override
	public boolean equals(Object other){
    	if (other == null) return false;
    	if (other == this) return true;
    	if (!(other instanceof Edge))return false;
    	Edge otherMyClass = (Edge)other;
    	return this.nodea.equals(otherMyClass.nodea) && this.nodeb.equals(otherMyClass.nodeb);
	}
}